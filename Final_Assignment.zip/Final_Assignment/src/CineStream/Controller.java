package CineStream;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * Controller for the small legacy hellofx.fxml sample view.
 *
 * The production pages are built programmatically, but this controller remains
 * in the project so the original FXML entry point can still be opened safely.
 */
public class Controller {

    /** Label injected by FXMLLoader from hellofx.fxml. */
    @FXML
    private Label label;

    /**
     * FXMLLoader calls this method after all @FXML fields are injected.
     * It displays the active Java and JavaFX versions for environment checks.
     */
    public void initialize() {
        String javaVersion = System.getProperty("java.version");
        String javafxVersion = System.getProperty("javafx.version");
        label.setText("Hello, JavaFX " + javafxVersion + "\nRunning on Java " + javaVersion + ".");
    }
}
