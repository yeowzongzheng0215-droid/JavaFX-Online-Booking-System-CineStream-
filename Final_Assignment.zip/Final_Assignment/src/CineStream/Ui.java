package CineStream;

import CineStream.Model.MovieData;
import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableNumberValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;

/**
 * Shared UI helpers for images, posters and atmospheric page backgrounds.
 */
public class Ui {

    private static final String[][] POSTER_GRADIENTS = {
            {"#7630e7", "#1c0e3f"},
            {"#0f62fe", "#0a1e4d"},
            {"#d63384", "#3d0a2a"},
            {"#12b886", "#052e22"},
            {"#f59f00", "#3d2400"},
            {"#e03131", "#3a0a0a"}
    };

    public static String posterStyle(int colorIndex) {
        String[] g = POSTER_GRADIENTS[colorIndex % POSTER_GRADIENTS.length];
        return "-fx-background-color: linear-gradient(to bottom right, " + g[0] + ", " + g[1] + ");";
    }

    /** Gradient fallback used only when a real poster image is unavailable. */
    public static StackPane moviePoster(MovieData m, double w, double h) {
        StackPane poster = new StackPane();
        poster.setPrefSize(w, h);
        poster.setMinSize(110, h);
        poster.setStyle(posterStyle(m.getColorIndex()));
        poster.getStyleClass().add("poster");

        Label initials = new Label(initials(m.getTitle()));
        initials.getStyleClass().add("poster-title");
        initials.setStyle("-fx-font-size: " + Math.round(w * 0.17) + "px;");
        StackPane.setAlignment(initials, Pos.CENTER);

        Label rating = new Label(m.getRating());
        rating.getStyleClass().add("rating-chip");
        StackPane.setAlignment(rating, Pos.TOP_RIGHT);
        StackPane.setMargin(rating, new Insets(10, 10, 0, 0));

        Label dur = new Label(m.getDuration() + " min");
        dur.getStyleClass().add("duration-chip");
        StackPane.setAlignment(dur, Pos.BOTTOM_LEFT);
        StackPane.setMargin(dur, new Insets(0, 0, 10, 10));

        poster.getChildren().addAll(initials, rating, dur);
        return poster;
    }

    /**
     * Returns the same real poster used on Home.  It is cropped with cover so
     * every card has a clean, consistent aspect ratio; the gradient poster is
     * retained as a safe fallback for missing assets.
     */
    public static StackPane moviePosterImage(MovieData movie, double width, double height, double radius) {
        Image image = ImageStore.poster(movie);
        StackPane poster;
        if (image != null) {
            poster = coverBox(image, new SimpleDoubleProperty(width), height, radius);
        } else {
            poster = moviePoster(movie, width, height);
        }
        poster.setPrefSize(width, height);
        poster.setMinSize(width, height);
        poster.setMaxSize(width, height);
        return poster;
    }

    /** System logo image view, scaled proportionally to the requested height. */
    public static ImageView logoView(double height) {
        Image img = ImageStore.logo();
        ImageView iv = new ImageView(img);
        iv.setFitHeight(height);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        Runnable update = () -> {
            Image n = iv.getImage();
            if (n != null && n.getWidth() > 0 && n.getHeight() > 0) {
                iv.setFitWidth(height * n.getWidth() / n.getHeight());
            }
        };
        iv.imageProperty().addListener((obs, o, n) -> update.run());
        if (img != null) {
            img.progressProperty().addListener((obs, o, n) -> {
                if (n.doubleValue() >= 1.0) update.run();
            });
        }
        update.run();
        return iv;
    }

    /** Movie title initials for poster fallbacks. */
    public static String initials(String title) {
        String[] words = title.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (String w : words) {
            if (!w.isEmpty() && count < 2) {
                sb.append(Character.toUpperCase(w.charAt(0)));
                count++;
            }
        }
        return sb.length() > 0 ? sb.toString() : "?";
    }

    /** Cover crop box with an optional rounded clip. */
    public static StackPane coverBox(Image img, ObservableNumberValue w,
                                     double fixedHeight, double radius) {
        StackPane box = new StackPane();
        box.setAlignment(Pos.CENTER);
        box.setMinSize(0, 0);
        box.setPrefHeight(fixedHeight);
        box.setMinHeight(fixedHeight);
        box.setMaxHeight(fixedHeight);

        ImageView iv = new ImageView(img);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        bindCover(iv, w, new SimpleDoubleProperty(fixedHeight));

        if (radius > 0) {
            Rectangle clip = new Rectangle();
            clip.widthProperty().bind(box.widthProperty());
            clip.heightProperty().bind(box.heightProperty());
            clip.setArcWidth(radius * 2);
            clip.setArcHeight(radius * 2);
            box.setClip(clip);
        }

        box.getChildren().add(iv);
        return box;
    }

    public static StackPane coverBox(Image img, ObservableNumberValue w, double fixedHeight) {
        return coverBox(img, w, fixedHeight, 0);
    }

    /** Contain box: the complete image remains visible and centred. */
    public static StackPane containBox(Image img, ObservableNumberValue w, double fixedHeight) {
        StackPane box = new StackPane();
        box.setAlignment(Pos.CENTER);
        box.setMinSize(0, 0);
        box.setPrefHeight(fixedHeight);
        box.setMinHeight(fixedHeight);
        box.setMaxHeight(fixedHeight);

        ImageView iv = new ImageView(img);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        bindContain(iv, w, new SimpleDoubleProperty(fixedHeight));
        box.getChildren().add(iv);
        return box;
    }

    /**
     * Full-page blurred image backdrop.  The lower half gradually returns to
     * CineStream's original dark-purple background so cards remain readable.
     */
    public static StackPane blurredBackdrop(Image image, Node foreground) {
        StackPane pane = new StackPane();
        pane.getStyleClass().add("page-backdrop");
        pane.setMinSize(0, 0);

        if (image != null) {
            ImageView background = new ImageView(image);
            background.setPreserveRatio(true);
            background.setSmooth(true);
            background.setManaged(false);
            background.setEffect(new GaussianBlur(18));
            background.setOpacity(0.82);
            bindCover(background, pane.widthProperty(), pane.heightProperty());
            pane.getChildren().add(background);
        }

        Rectangle shade = new Rectangle();
        shade.widthProperty().bind(pane.widthProperty());
        shade.heightProperty().bind(pane.heightProperty());
        shade.setFill(Color.rgb(4, 3, 10, 0.38));
        shade.setMouseTransparent(true);

        Rectangle fade = new Rectangle();
        fade.widthProperty().bind(pane.widthProperty());
        fade.heightProperty().bind(pane.heightProperty());
        fade.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0.00, Color.rgb(5, 5, 13, 0.05)),
                new Stop(0.45, Color.rgb(8, 5, 18, 0.14)),
                new Stop(0.72, Color.rgb(18, 8, 38, 0.78)),
                new Stop(1.00, Color.rgb(30, 14, 63, 0.98))));
        fade.setMouseTransparent(true);

        pane.getChildren().addAll(shade, fade, foreground);

        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(pane.widthProperty());
        clip.heightProperty().bind(pane.heightProperty());
        pane.setClip(clip);
        return pane;
    }

    /** Public image-view helper used by reusable banner components. */
    public static ImageView coverImage(Image image, ObservableNumberValue width,
                                       ObservableNumberValue height) {
        ImageView view = new ImageView(image);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        bindCover(view, width, height);
        return view;
    }

    /** Public contain image-view helper used by reusable banner components. */
    public static ImageView containImage(Image image, ObservableNumberValue width,
                                         ObservableNumberValue height) {
        ImageView view = new ImageView(image);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        bindContain(view, width, height);
        return view;
    }

    private static void bindCover(ImageView iv, ObservableNumberValue w, ObservableNumberValue h) {
        iv.setManaged(false);
        InvalidationListener listener = obs -> {
            double bw = w.doubleValue();
            double bh = h.doubleValue();
            Image img = iv.getImage();
            if (bw <= 0 || bh <= 0 || img == null) return;
            double iw = img.getWidth();
            double ih = img.getHeight();
            if (iw <= 0 || ih <= 0) return;
            double scale = Math.max(bw / iw, bh / ih);
            double fw = iw * scale;
            double fh = ih * scale;
            iv.setFitWidth(fw);
            iv.setFitHeight(fh);
            iv.setLayoutX((bw - fw) / 2);
            iv.setLayoutY((bh - fh) / 2);
        };
        w.addListener(listener);
        h.addListener(listener);
        iv.imageProperty().addListener((obs, old, now) -> listener.invalidated(null));
        listener.invalidated(null);
    }

    private static void bindContain(ImageView iv, ObservableNumberValue w, ObservableNumberValue h) {
        iv.setManaged(false);
        InvalidationListener listener = obs -> {
            double bw = w.doubleValue();
            double bh = h.doubleValue();
            Image img = iv.getImage();
            if (bw <= 0 || bh <= 0 || img == null) return;
            double iw = img.getWidth();
            double ih = img.getHeight();
            if (iw <= 0 || ih <= 0) return;
            double scale = Math.min(bw / iw, bh / ih);
            double fw = iw * scale;
            double fh = ih * scale;
            iv.setFitWidth(fw);
            iv.setFitHeight(fh);
            iv.setLayoutX((bw - fw) / 2);
            iv.setLayoutY((bh - fh) / 2);
        };
        w.addListener(listener);
        h.addListener(listener);
        iv.imageProperty().addListener((obs, old, now) -> listener.invalidated(null));
        listener.invalidated(null);
    }
}
