package CineStream;

import CineStream.Model.Seat;
import CineStream.Model.SeatMap;
import CineStream.Model.Showtime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Thread-safe seat locking and duplicate-booking prevention. */
public class BookingUtils {
    /**
     * Keys identify hall + showtime + coordinate. The set supplements Seat.Status
     * and records only seats locked by this workflow; seeded sold seats therefore
     * cannot be accidentally released by the Modify Seats action.
     */
    private static final Set<String> BOOKED_KEYS = new HashSet<>();

    /**
     * Atomically commits all requested seats.  SELECTED seats are valid input;
     * an already BOOKED seat (including a seeded sold seat) rejects the whole
     * request, so no partial booking is possible.
     */
    public static synchronized boolean bookSeats(Showtime showtime, List<Seat> seats) {
        if (showtime == null || seats == null || seats.isEmpty()) return false;

        SeatMap seatMap = showtime.getSeatMap();
        Seat[][] actualSeats = seatMap.getSeats();

        // Validation pass: reject the complete request before mutating any seat.
        for (Seat requested : seats) {
            if (!isInside(actualSeats, requested.getRow(), requested.getCol())) return false;
            Seat actual = actualSeats[requested.getRow()][requested.getCol()];
            if (actual.getStatus() == Seat.Status.BOOKED
                    || BOOKED_KEYS.contains(key(showtime, actual))) {
                return false;
            }
        }

        // Commit pass: all coordinates are safe, so mark them as one atomic group.
        for (Seat requested : seats) {
            Seat actual = actualSeats[requested.getRow()][requested.getCol()];
            if (!seatMap.bookSeat(actual.getRow(), actual.getCol())) {
                return false; // guarded above; retained as a defensive check
            }
            BOOKED_KEYS.add(key(showtime, actual));
            requested.setStatus(Seat.Status.BOOKED);
        }
        return true;
    }

    /**
     * Releases only seats locked by this booking flow.  Seeded/already sold
     * seats do not have a key in BOOKED_KEYS and therefore can never be freed.
     */
    public static synchronized void releaseSeats(Showtime showtime, List<Seat> seats) {
        if (showtime == null || seats == null) return;

        Seat[][] actualSeats = showtime.getSeatMap().getSeats();
        for (Seat requested : seats) {
            if (!isInside(actualSeats, requested.getRow(), requested.getCol())) continue;
            Seat actual = actualSeats[requested.getRow()][requested.getCol()];
            if (BOOKED_KEYS.remove(key(showtime, actual))) {
                actual.setStatus(Seat.Status.AVAILABLE);
                requested.setStatus(Seat.Status.AVAILABLE);
            }
        }
    }

    /** SeatPage calls this immediately before toggling a button to avoid stale UI state. */
    public static synchronized boolean isBooked(Showtime showtime, Seat seat) {
        if (showtime == null || seat == null) return false;
        Seat[][] seats = showtime.getSeatMap().getSeats();
        if (!isInside(seats, seat.getRow(), seat.getCol())) return false;
        Seat actual = seats[seat.getRow()][seat.getCol()];
        return actual.getStatus() == Seat.Status.BOOKED
                || BOOKED_KEYS.contains(key(showtime, actual));
    }

    /** Builds the stable identity used for duplicate-booking checks. */
    private static String key(Showtime showtime, Seat seat) {
        return "HALL_" + showtime.getHall().getHallId()
                + "_" + showtime.getTime()
                + "_R" + seat.getRow() + "C" + seat.getCol();
    }

    private static boolean isInside(Seat[][] seats, int row, int col) {
        return row >= 0 && row < seats.length
                && col >= 0 && col < seats[row].length;
    }
}
