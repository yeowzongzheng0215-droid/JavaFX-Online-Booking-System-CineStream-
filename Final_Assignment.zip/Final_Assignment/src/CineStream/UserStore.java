package CineStream;

import java.util.HashMap;
import java.util.Map;

/**
 * In-memory user repository. Accounts exist only for the current application run.
 *
 * This assignment intentionally has no database: email/password pairs are kept
 * as plain runtime values for demonstrating page interaction only. A production
 * system would hash passwords and use persistent storage.
 */
public class UserStore {
    // One shared repository is used by both registration and login pages.
    private static UserStore instance;
    // Email is the normalized lookup key; the assignment stores passwords in memory.
    private final Map<String, String> registeredUsers = new HashMap<>();

    // Private constructor enforces singleton access through getInstance().
    private UserStore() {}

    // Lazily create the repository on first use.
    public static UserStore getInstance() {
        if (instance == null) {
            instance = new UserStore();
        }
        return instance;
    }

    // Register an account after SignUpPage has validated its input.
    public void register(String email, String password) {
        if (email != null && password != null) {
            registeredUsers.put(email.trim().toLowerCase(), password);
        }
    }

    // SignUpPage uses this check to prevent duplicate accounts.
    public boolean isRegistered(String email) {
        if (email == null) return false;
        return registeredUsers.containsKey(email.trim().toLowerCase());
    }

    // LoginPage uses this method to authenticate submitted credentials.
    public boolean validateLogin(String email, String password) {
        if (email == null || password == null) return false;
        String storedPassword = registeredUsers.get(email.trim().toLowerCase());
        return storedPassword != null && storedPassword.equals(password);
    }

    // Optional test/reset hook; shutdown also discards this in-memory data.
    public void clearAll() {
        registeredUsers.clear();
    }
}
