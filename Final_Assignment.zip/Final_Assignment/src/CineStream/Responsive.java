package CineStream;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;

/** Responsive scroll-layout helpers shared by all pages. */
public class Responsive {

    /**
     * Creates a persistent vertical ScrollPane.
     *
     * Full-width pages are attached directly to the viewport.  The previous
     * extra StackPane wrapper could be stretched to viewport height during the
     * first layout pulse, making the bottom look clipped until window resize.
     * A wrapper is retained only when a maximum centred width is requested.
     */
    public static ScrollPane wrapScroll(Pane content, double cap) {
        final Node scrollContent;
        if (cap > 0) {
            content.setMaxWidth(cap);
            StackPane centred = new StackPane(content);
            centred.setMinWidth(0);
            centred.setAlignment(Pos.TOP_CENTER);
            scrollContent = centred;
        } else {
            content.setMaxWidth(Double.MAX_VALUE);
            scrollContent = content;
        }

        ScrollPane scroll = new ScrollPane(scrollContent);
        scroll.getStyleClass().add("persistent-scroll");
        scroll.setFitToWidth(true);
        scroll.setFitToHeight(false);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scroll.setPannable(false);
        scroll.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

        // Recalculate once the ScrollPane is attached and its skin exists.
        scroll.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                Platform.runLater(() -> {
                    scroll.applyCss();
                    scroll.requestLayout();
                    if (scroll.getContent() instanceof Parent) {
                        ((Parent) scroll.getContent()).requestLayout();
                    }
                });
            }
        });
        return scroll;
    }

    /**
     * Scroll container that fills the available viewport height.  Used for
     * centred authentication cards and for pushing a short page footer down.
     */
    public static ScrollPane wrapScrollFill(Pane content, double cap) {
        ScrollPane scroll = wrapScroll(content, cap);
        scroll.getStyleClass().remove("persistent-scroll");
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        content.minHeightProperty().bind(Bindings.createDoubleBinding(
                () -> Math.max(0, scroll.getViewportBounds().getHeight()),
                scroll.viewportBoundsProperty()));
        return scroll;
    }
}
