package CineStream;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-width movie banner carousel with complete-image foreground display.
 *
 * - Foreground: the movie banner follows the window width and uses HEIGHT=600.
 *   Contain scaling keeps the whole image visible, proportional and centred.
 * - Background: a cover-scaled, blurred and dimmed copy fills side gaps.
 *   This preserves a continuous full-width visual while the foreground stays clear.
 * - Transition: the old and new images cross-fade together for 1.3 seconds.
 * - Navigation arrows sit at both edges and animate on hover.
 * - Clickable indicator dots provide direct slide navigation.
 * - Manual navigation restarts the automatic rotation timer.
 */
public class BannerSlider extends StackPane {

    public static final double HOLD_SEC = 5.0;   // seconds each slide remains visible
    public static final double FADE_SEC = 1.3;   // cross-fade duration for a smooth transition
    public static final double HEIGHT = 600;     // default carousel height

    /** Opacity of the blurred fill layer behind the clear foreground image. */
    private static final double BG_OPACITY = 0.85;

    private final List<ImageView> fgViews = new ArrayList<>();
    private final List<ImageView> bgViews = new ArrayList<>();
    private final List<Circle> dots = new ArrayList<>();
    private final StackPane fgBox = new StackPane();
    private final StackPane bgBox = new StackPane();

    private int current = 0;
    private Timeline auto;
    private boolean transitioning = false;

    public BannerSlider(List<Image> banners, List<String> titles) {
        this(banners, titles, HEIGHT);
    }

    /** Same carousel design with a page-specific display height. */
    public BannerSlider(List<Image> banners, List<String> titles, double bannerHeight) {
        setPrefHeight(bannerHeight);
        setMinHeight(bannerHeight);
        setMaxHeight(bannerHeight);
        setMinWidth(0);
        setAlignment(Pos.CENTER);

        if (banners == null || banners.isEmpty()) return;

        /* ===== Blurred cover background: fills gaps around the contained image ===== */
        bgBox.setAlignment(Pos.CENTER);
        bgBox.prefWidthProperty().bind(widthProperty());
        bgBox.prefHeightProperty().bind(heightProperty());
        bgBox.setMinWidth(0);
        bgBox.setMinHeight(0);

        for (int i = 0; i < banners.size(); i++) {
            ImageView bgIv = new ImageView(banners.get(i));
            bgIv.setPreserveRatio(true);
            bgIv.setSmooth(true);
            bgIv.setEffect(new GaussianBlur(22));
            bgIv.setOpacity(i == 0 ? BG_OPACITY : 0.0);
            bindCover(bgIv, bgBox.widthProperty(), bgBox.heightProperty());
            bgIv.setVisible(i == 0);
            bgViews.add(bgIv);
            bgBox.getChildren().add(bgIv);
        }
        // Clip the cover layer so oversized image pixels never leave this component
        // or overlap content such as authentication cards above the carousel.
        Rectangle bgClip = new Rectangle();
        bgClip.widthProperty().bind(bgBox.widthProperty());
        bgClip.heightProperty().bind(bgBox.heightProperty());
        bgBox.setClip(bgClip);

        // Dim only the blurred fill layer; the clear foreground is added later.
        Rectangle dark = new Rectangle();
        dark.setFill(Color.rgb(4, 4, 12, 0.45));
        dark.widthProperty().bind(bgBox.widthProperty());
        dark.heightProperty().bind(bgBox.heightProperty());
        bgBox.getChildren().add(dark);

        getChildren().add(bgBox);

        /* ===== Foreground layer: contained completely without cropping ===== */
        fgBox.setAlignment(Pos.CENTER);
        fgBox.prefWidthProperty().bind(widthProperty());
        fgBox.maxWidthProperty().bind(widthProperty());
        fgBox.setPrefHeight(bannerHeight);
        fgBox.setMinWidth(0);
        fgBox.setMinHeight(bannerHeight);
        fgBox.setMaxHeight(bannerHeight);

        // The clip is a defensive boundary even though contain scaling should not overflow.
        Rectangle fgClip = new Rectangle();
        fgClip.widthProperty().bind(fgBox.widthProperty());
        fgClip.heightProperty().bind(fgBox.heightProperty());
        fgBox.setClip(fgClip);

        for (int i = 0; i < banners.size(); i++) {
            ImageView fgIv = new ImageView(banners.get(i));
            fgIv.setPreserveRatio(true);
            fgIv.setSmooth(true);
            bindContain(fgIv, fgBox.widthProperty(), fgBox.heightProperty());
            fgIv.setOpacity(1.0);
            fgIv.setVisible(i == 0);
            fgViews.add(fgIv);
            fgBox.getChildren().add(fgIv);
        }

        // Fade the lower image into the page background, below controls but above images.
        Rectangle fade = new Rectangle();
        fade.setFill(new javafx.scene.paint.LinearGradient(0, 1, 0, 0, true,
                javafx.scene.paint.CycleMethod.NO_CYCLE,
                new javafx.scene.paint.Stop(0, Color.rgb(6, 5, 14, 0.95)),
                new javafx.scene.paint.Stop(0.50, Color.rgb(6, 5, 14, 0.0))));
        fade.widthProperty().bind(fgBox.widthProperty());
        fade.heightProperty().bind(fgBox.heightProperty());
        fgBox.getChildren().add(fade);

        getChildren().add(fgBox);

        /* ================= Previous / next navigation arrows ================= */
        Button left = arrowButton("\u2039", "Previous movie");
        left.setOnAction(e -> jumpTo(prevIndex()));
        getChildren().add(left);
        StackPane.setAlignment(left, Pos.CENTER_LEFT);
        StackPane.setMargin(left, new Insets(0, 0, 0, 24));

        Button right = arrowButton("\u203A", "Next movie");
        right.setOnAction(e -> jumpTo(nextIndex()));
        getChildren().add(right);
        StackPane.setAlignment(right, Pos.CENTER_RIGHT);
        StackPane.setMargin(right, new Insets(0, 24, 0, 0));

        /* ================= Clickable slide indicator dots ================= */
        HBox dotRow = new HBox(9);
        dotRow.setAlignment(Pos.CENTER);
        dotRow.setMaxWidth(Region.USE_PREF_SIZE);
        dotRow.setMaxHeight(Region.USE_PREF_SIZE);
        for (int i = 0; i < banners.size(); i++) {
            final int idx = i;
            Circle dot = new Circle(5);
            dot.getStyleClass().add("banner-dot");
            if (i == 0) dot.getStyleClass().add("banner-dot-active");
            if (titles != null && i < titles.size()) {
                Tooltip.install(dot, new Tooltip(titles.get(i)));
            }
            dot.setOnMouseClicked(e -> jumpTo(idx));
            dots.add(dot);
            dotRow.getChildren().add(dot);
        }
        getChildren().add(dotRow);
        StackPane.setAlignment(dotRow, Pos.BOTTOM_CENTER);
        StackPane.setMargin(dotRow, new Insets(0, 0, 14, 0));

        if (banners.size() > 1) startAuto();
    }

    private Button arrowButton(String glyph, String tip) {
        Button b = new Button(glyph);
        b.getStyleClass().add("banner-arrow");
        b.setTooltip(new Tooltip(tip));
        b.setPrefSize(48, 48);
        b.setMinSize(48, 48);
        b.setMaxSize(48, 48);

        ScaleTransition in = new ScaleTransition(Duration.millis(140), b);
        in.setToX(1.14);
        in.setToY(1.14);
        ScaleTransition out = new ScaleTransition(Duration.millis(140), b);
        out.setToX(1.0);
        out.setToY(1.0);
        b.setOnMouseEntered(e -> in.playFromStart());
        b.setOnMouseExited(e -> out.playFromStart());
        return b;
    }

    private int nextIndex() { return (current + 1) % fgViews.size(); }
    private int prevIndex() { return (current - 1 + fgViews.size()) % fgViews.size(); }

    /* ================= Automatic rotation ================= */

    private void startAuto() {
        if (auto != null) auto.stop();
        auto = new Timeline(new KeyFrame(Duration.seconds(HOLD_SEC), e -> {
            if (!transitioning) {
                crossFadeTo(nextIndex());
            }
        }));
        auto.play();
    }

    /* ================= Synchronized foreground/background cross-fade ================= */

    private void crossFadeTo(int target) {
        if (target == current || transitioning || target < 0 || target >= fgViews.size()) return;
        transitioning = true;

        ImageView curFg = fgViews.get(current);
        ImageView nextFg = fgViews.get(target);
        ImageView curBg = bgViews.get(current);
        ImageView nextBg = bgViews.get(target);

        nextFg.setVisible(true);
        nextBg.setVisible(true);
        nextFg.setOpacity(0);
        nextBg.setOpacity(0);

        current = target;
        updateDots();

        // Fade both foreground and background pairs together to avoid a visual jump.
        Timeline tl = new Timeline(
                new KeyFrame(Duration.ZERO,
                        new KeyValue(curFg.opacityProperty(), 1),
                        new KeyValue(nextFg.opacityProperty(), 0),
                        new KeyValue(curBg.opacityProperty(), BG_OPACITY),
                        new KeyValue(nextBg.opacityProperty(), 0)),
                new KeyFrame(Duration.seconds(FADE_SEC),
                        new KeyValue(curFg.opacityProperty(), 0),
                        new KeyValue(nextFg.opacityProperty(), 1),
                        new KeyValue(curBg.opacityProperty(), 0),
                        new KeyValue(nextBg.opacityProperty(), BG_OPACITY)),
                new KeyFrame(Duration.seconds(FADE_SEC + 0.05), e -> {
                    curFg.setVisible(false);
                    curFg.setOpacity(1);          // restore opacity for the next transition
                    curBg.setVisible(false);
                    curBg.setOpacity(BG_OPACITY);
                    transitioning = false;
                    startAuto();
                })
        );
        tl.play();
    }

    /** Starts a manual cross-fade and resets the automatic timer. */
    private void jumpTo(int target) {
        if (target == current || transitioning) return;
        if (auto != null) auto.stop();
        crossFadeTo(target);
    }

    private void updateDots() {
        for (int i = 0; i < dots.size(); i++) {
            dots.get(i).getStyleClass().remove("banner-dot-active");
            if (i == current) {
                dots.get(i).getStyleClass().add("banner-dot-active");
            }
        }
    }

    /* ================= Image sizing helpers ================= */

    /** Cover scaling for the background layer; positioning is calculated manually. */
    private static void bindCover(ImageView iv, ReadOnlyDoubleProperty w, ReadOnlyDoubleProperty h) {
        iv.setManaged(false);
        InvalidationListener l = obs -> {
            double bw = w.get(), bh = h.get();
            Image img = iv.getImage();
            if (bw <= 0 || bh <= 0 || img == null) return;
            double iw = img.getWidth(), ih = img.getHeight();
            if (iw <= 0 || ih <= 0) return;
            double s = Math.max(bw / iw, bh / ih);
            double fw = iw * s, fh = ih * s;
            iv.setFitWidth(fw);
            iv.setFitHeight(fh);
            iv.setLayoutX((bw - fw) / 2);
            iv.setLayoutY((bh - fh) / 2);
        };
        w.addListener(l);
        h.addListener(l);
        iv.imageProperty().addListener((obs, old, now) -> l.invalidated(null));
        l.invalidated(null);
    }

    /** Contain scaling for the foreground; keeps the whole image centred and visible. */
    private static void bindContain(ImageView iv, ReadOnlyDoubleProperty w, ReadOnlyDoubleProperty h) {
        iv.setManaged(false);
        InvalidationListener l = obs -> {
            double bw = w.get(), bh = h.get();
            Image img = iv.getImage();
            if (bw <= 0 || bh <= 0 || img == null) return;
            double iw = img.getWidth(), ih = img.getHeight();
            if (iw <= 0 || ih <= 0) return;
            double s = Math.min(bw / iw, bh / ih);
            double fw = iw * s, fh = ih * s;
            iv.setFitWidth(fw);
            iv.setFitHeight(fh);
            iv.setLayoutX((bw - fw) / 2);
            iv.setLayoutY((bh - fh) / 2);
        };
        w.addListener(l);
        h.addListener(l);
        iv.imageProperty().addListener((obs, old, now) -> l.invalidated(null));
        l.invalidated(null);
    }
}
