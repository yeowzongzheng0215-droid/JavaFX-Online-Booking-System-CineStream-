package CineStream;

import CineStream.Model.MovieData;
import CineStream.Model.ScreeningHall;
import CineStream.Model.Seat;
import CineStream.Model.Showtime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Shared in-memory movie catalogue. Halls and showtimes are initialized once
 * so revisiting MoviePage never recreates halls or exceeds the hall limit.
 */
public class MovieCatalogue {
    private static List<MovieData> movies = null;
    private static List<Showtime> showtimes = null;

    /** Returns the shared movie objects used by HomePage and MoviePage. */
    public static synchronized List<MovieData> getMovies() {
        ensureInit();
        return movies;
    }

    /** Returns every performance; MoviePage filters this list by selected movie. */
    public static synchronized List<Showtime> getShowtimes() {
        ensureInit();
        return showtimes;
    }

    /** Lazily builds all data on the first catalogue request. */
    private static void ensureInit() {
        if (movies != null) return;

        // Movie instances are shared by image lookup, showtimes and UserSession.
        movies = new ArrayList<>();
        movies.add(new MovieData("The Wandering Earth 3", "", "Sci-Fi / Action", 145, 0, "P13"));
        movies.add(new MovieData("Zootopia 2", "", "Animation / Adventure", 110, 1, "U"));
        movies.add(new MovieData("Avengers: Final Chapter", "", "Superhero / Action", 160, 2, "P13"));
        movies.add(new MovieData("The Forbidden Kingdom", "", "Adventure / Fantasy", 128, 3, "P13"));
        movies.add(new MovieData("Dune: Part Three", "", "Sci-Fi / Epic", 165, 4, "18"));
        movies.add(new MovieData("Romantic Seoul", "", "Romance / Drama", 105, 5, "P13"));

        // Halls define names and dimensions; each Showtime receives its own SeatMap.
        ScreeningHall h1 = new ScreeningHall("Hall 1 (IMAX)", 8, 10);
        ScreeningHall h2 = new ScreeningHall("Hall 2 (4K)", 7, 9);
        ScreeningHall h3 = new ScreeningHall("Hall 3 (Standard)", 6, 8);
        ScreeningHall h4 = new ScreeningHall("Hall 4 (IMAX)", 8, 10);
        ScreeningHall h5 = new ScreeningHall("Hall 5 (4K)", 7, 9);
        ScreeningHall h6 = new ScreeningHall("Hall 6 (Standard)", 6, 8);

        // Performances use today's date and fixed demonstration times.
        showtimes = new ArrayList<>();
        showtimes.add(new Showtime(movies.get(0), LocalDateTime.now().withHour(10).withMinute(0), h1));
        showtimes.add(new Showtime(movies.get(0), LocalDateTime.now().withHour(15).withMinute(30), h1));
        showtimes.add(new Showtime(movies.get(0), LocalDateTime.now().withHour(20).withMinute(45), h4));
        showtimes.add(new Showtime(movies.get(1), LocalDateTime.now().withHour(12).withMinute(0), h2));
        showtimes.add(new Showtime(movies.get(1), LocalDateTime.now().withHour(18).withMinute(0), h2));
        showtimes.add(new Showtime(movies.get(1), LocalDateTime.now().withHour(21).withMinute(30), h5));
        showtimes.add(new Showtime(movies.get(2), LocalDateTime.now().withHour(14).withMinute(0), h3));
        showtimes.add(new Showtime(movies.get(2), LocalDateTime.now().withHour(20).withMinute(0), h3));
        showtimes.add(new Showtime(movies.get(2), LocalDateTime.now().withHour(22).withMinute(30), h6));
        showtimes.add(new Showtime(movies.get(3), LocalDateTime.now().withHour(11).withMinute(30), h4));
        showtimes.add(new Showtime(movies.get(3), LocalDateTime.now().withHour(17).withMinute(15), h5));
        showtimes.add(new Showtime(movies.get(4), LocalDateTime.now().withHour(13).withMinute(0), h6));
        showtimes.add(new Showtime(movies.get(4), LocalDateTime.now().withHour(19).withMinute(30), h1));
        showtimes.add(new Showtime(movies.get(5), LocalDateTime.now().withHour(16).withMinute(0), h2));
        showtimes.add(new Showtime(movies.get(5), LocalDateTime.now().withHour(22).withMinute(0), h3));

        // Seed sold seats independently for each showtime.  A booking for one
        // performance no longer leaks into another film using the same hall.
        int[][] bookedSeats = {{0,2},{1,3},{1,4},{2,0},{2,7},{3,2},{4,4},{4,5},{5,1},{5,6}};
        for (Showtime showtime : showtimes) {
            Seat[][] seatRows = showtime.getSeatMap().getSeats();
            for (int[] rc : bookedSeats) {
                int r = rc[0], c = rc[1];
                if (r < seatRows.length && c < seatRows[r].length) {
                    seatRows[r][c].setStatus(Seat.Status.BOOKED);
                }
            }
        }
    }
}
