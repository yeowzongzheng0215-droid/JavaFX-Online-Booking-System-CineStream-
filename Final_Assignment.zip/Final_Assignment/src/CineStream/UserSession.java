package CineStream;

import CineStream.Model.MovieData;
import CineStream.Model.Seat;
import CineStream.Model.Showtime;
import java.util.ArrayList;
import java.util.List;

/**
 * Shared state that carries one user's identity and current booking between pages.
 *
 * Page objects are recreated during navigation, so they cannot rely on local
 * fields to retain a movie, showtime or seats. Each step writes its validated
 * choice here and the next step reads it from the same singleton instance.
 */
public class UserSession {
    private static UserSession instance;

    /** Non-null username is also the application's logged-in flag. */
    private String username;

    /** In-progress booking selections, populated in workflow order. */
    private MovieData selectedMovie;
    private Showtime selectedShowtime;
    private final List<Seat> selectedSeats = new ArrayList<>();

    private UserSession() {}

    /** Returns the single session shared by navigation, pages and receipt code. */
    public static UserSession getInstance() {
        if (instance == null) instance = new UserSession();
        return instance;
    }

    public boolean isLoggedIn() {
        return username != null;
    }

    /** Called only after LoginPage validates credentials against UserStore. */
    public void login(String username) {
        this.username = username;
    }

    /** Logout clears identity and all unfinished page-to-page booking state. */
    public void logout() {
        this.username = null;
        clearBookingSelection();
    }

    public String getUsername() { return username; }

    public MovieData getSelectedMovie() { return selectedMovie; }

    /**
     * Selecting a different movie invalidates its previous showtime and seats,
     * preventing stale choices from leaking into a new booking.
     */
    public void setSelectedMovie(MovieData selectedMovie) {
        if (this.selectedMovie != selectedMovie) {
            this.selectedShowtime = null;
            this.selectedSeats.clear();
        }
        this.selectedMovie = selectedMovie;
    }

    public Showtime getSelectedShowtime() { return selectedShowtime; }

    /** A new performance has a different SeatMap, so old seat references are cleared. */
    public void setSelectedShowtime(Showtime selectedShowtime) {
        if (this.selectedShowtime != selectedShowtime) {
            this.selectedSeats.clear();
        }
        this.selectedShowtime = selectedShowtime;
    }

    /** Returns the live list used by summaries; callers copy it for permanent records. */
    public List<Seat> getSelectedSeats() { return selectedSeats; }

    /** Replaces the current selection after BookingUtils successfully locks the seats. */
    public void setSelectedSeats(List<Seat> selectedSeats) {
        this.selectedSeats.clear();
        if (selectedSeats != null) {
            this.selectedSeats.addAll(selectedSeats);
        }
    }

    /** Starts another order without logging the member out. */
    public void clearBookingSelection() {
        this.selectedMovie = null;
        this.selectedShowtime = null;
        this.selectedSeats.clear();
    }
}
