package CineStream;

import CineStream.Model.MovieData;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Central image-resource repository:
 * - Real assets under src/CineStream/images follow these names:
 *     poster-<movie-slug>.png|jpg
 *     banner-<movie-slug>.png|jpg
 * - A generated colour-matched banner keeps the UI complete when an asset is absent.
 */
public class ImageStore {

    private static final String[][] PALETTES = {
            {"#7630e7", "#1c0e3f"},   // purple
            {"#0f62fe", "#0a1e4d"},   // blue
            {"#d63384", "#3d0a2a"},   // pink
            {"#12b886", "#052e22"},   // green
            {"#f59f00", "#3d2400"},   // orange
            {"#e03131", "#3a0a0a"}    // red
    };

    /** Returns a movie banner, generating a gradient fallback when necessary. */
    public static Image banner(MovieData m) {
        Image img = load("banner-" + slug(m.getTitle()));
        return img != null ? img : generateBanner(m);
    }

    /** Returns a movie poster, or null so the caller can render its fallback. */
    public static Image poster(MovieData m) {
        return load("poster-" + slug(m.getTitle()));
    }

    /** Returns the application logo from images/logo.png. */
    public static Image logo() {
        return load("logo");
    }

    /** Returns the popcorn background shared by Login, Sign Up and My Tickets. */
    public static Image popcornBackground() {
        return load("background-popcorn");
    }

    /** Returns the red stage-curtain background used by About. */
    public static Image curtainBackground() {
        return load("background-curtain");
    }

    /** Converts a movie title into its resource filename slug. */
    public static String slug(String title) {
        return title.trim().toLowerCase()
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
    }

    /** Tries supported extensions in order and returns the first classpath match. */
    private static Image load(String name) {
        for (String ext : new String[]{"png", "jpg", "jpeg"}) {
            var url = ImageStore.class.getResource("images/" + name + "." + ext);
            if (url != null) {
                return new Image(url.toExternalForm());
            }
        }
        return null;
    }

    /** Generates a 1600 x 700 gradient banner fallback. */
    public static Image generateBanner(MovieData m) {
        int w = 1600, h = 700;
        WritableImage img = new WritableImage(w, h);
        Canvas cv = new Canvas(w, h);
        GraphicsContext g = cv.getGraphicsContext2D();

        String[] pal = PALETTES[m.getColorIndex() % PALETTES.length];
        LinearGradient lg = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0, Color.web(pal[0])), new Stop(1, Color.web(pal[1])));
        g.setFill(lg);
        g.fillRect(0, 0, w, h);

        // Decorative highlights add depth to the generated fallback.
        g.setFill(Color.rgb(255, 255, 255, 0.09));
        g.fillOval(w * 0.70, -140, 440, 440);
        g.setFill(Color.rgb(0, 0, 0, 0.20));
        g.fillOval(-180, h * 0.52, 460, 460);

        // Draw the movie title at the visual centre.
        String title = m.getTitle();
        double fs = title.length() > 22 ? 46 : 62;
        g.setFill(Color.WHITE);
        g.setFont(Font.font("Segoe UI", FontWeight.BOLD, fs));
        double tw = fs * title.length() * 0.60;
        g.fillText(title, (w - tw) / 2, h / 2 - 8);

        // Add genre, running time and rating as supporting metadata.
        g.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 22));
        g.setFill(Color.rgb(255, 255, 255, 0.85));
        String sub = m.getGenre() + "   •   " + m.getDuration() + " min   •   " + m.getRating();
        double sw = 22 * sub.length() * 0.52;
        g.fillText(sub, (w - sw) / 2, h / 2 + 44);

        return cv.snapshot(null, img);
    }
}
