package CineStream.Page;

import CineStream.BookingUtils;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.UserSession;
import CineStream.Model.ReceiptGenerator;
import CineStream.Model.Seat;
import CineStream.Model.SeatMap;
import CineStream.Model.Showtime;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Interactive seat-selection step for the Showtime stored in UserSession.
 *
 * The page maps every domain Seat to one Button, keeps temporary selections in
 * selectedSeats, mirrors them in the summary, and asks BookingUtils to atomically
 * lock the complete set before navigating to PricePage. BOOKED seats are always
 * rechecked at interaction time and can never be toggled back to available.
 */
public class SeatPage {
    private static final DateTimeFormatter SHOWTIME_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, dd MMM  HH:mm", Locale.ENGLISH);
    private static final double PRICE_PER_SEAT = ReceiptGenerator.PRICE_PER_SEAT;

    private final MainApp app;
    private final BorderPane root;

    /** HashSet gives fast toggle checks and prevents duplicate seat selections. */
    private final Set<Seat> selectedSeats = new HashSet<>();
    private final Label lblSeatCount;
    private final Label lblTotalPrice;
    private final FlowPane seatTagFlow;
    private Button[][] seatButtons;

    public SeatPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "movies"));

        // MoviePage guarantees a selected Showtime before this page is opened.
        UserSession session = UserSession.getInstance();
        Showtime showtime = session.getSelectedShowtime();
        SeatMap seatMap = showtime.getSeatMap();

        VBox center = new VBox(0);
        center.getChildren().addAll(
                new StepsBar(1),
                new MovieHeroBanner(showtime.getMovie()));

        HBox body = new HBox(24);
        // Generous bottom breathing room keeps the seat GUI away from the
        // viewport edge even before any manual window resize/layout pulse.
        body.setPadding(new Insets(28, 30, 92, 30));
        body.setAlignment(Pos.TOP_CENTER);
        body.setMaxWidth(1160);

        /* ================= Larger seat-map card ================= */
        VBox left = new VBox(13);
        left.getStyleClass().addAll("card", "seat-layout-card");
        left.setPadding(new Insets(24, 28, 24, 28));
        left.setPrefWidth(740);
        left.setMinWidth(590);
        left.setMaxWidth(760);
        HBox.setHgrow(left, Priority.ALWAYS);

        Label title = new Label(showtime.getMovie().getTitle());
        title.getStyleClass().add("section-title");
        title.setStyle("-fx-font-size: 19px; -fx-padding: 0;");

        HBox meta = new HBox(10);
        meta.setAlignment(Pos.CENTER_LEFT);
        Label hallChip = chip(showtime.getHall().getName());
        Label timeChip = chip(showtime.getTime().format(SHOWTIME_FORMAT));
        meta.getChildren().addAll(hallChip, timeChip);

        StackPane screenBox = new StackPane();
        screenBox.setPrefSize(640, 76);
        screenBox.setMinSize(500, 76);
        screenBox.setMaxSize(Double.MAX_VALUE, 76);
        Arc arc = new Arc(0, 0, 292, 45, 0, 180);
        arc.setType(ArcType.OPEN);
        arc.getStyleClass().add("screen-arc");
        arc.setStrokeWidth(0);
        Label screenLbl = new Label("S C R E E N");
        screenLbl.getStyleClass().add("screen-label");
        StackPane.setAlignment(screenLbl, Pos.TOP_CENTER);
        StackPane.setMargin(screenLbl, new Insets(17, 0, 0, 0));
        screenBox.getChildren().addAll(arc, screenLbl);

        GridPane grid = new GridPane();
        grid.setHgap(6);
        grid.setVgap(6);
        grid.setAlignment(Pos.CENTER);

        // Render the showtime-owned model grid; button indices mirror seat coordinates.
        Seat[][] seats = seatMap.getSeats();
        int rows = seats.length;
        int cols = rows > 0 ? seats[0].length : 0;
        seatButtons = new Button[rows][cols];

        for (int c = 0; c < cols; c++) {
            Label colLabel = new Label(String.valueOf(c + 1));
            colLabel.getStyleClass().add("seat-col-label");
            grid.add(colLabel, c + 1, 0);
        }

        for (int r = 0; r < rows; r++) {
            Label rowLabel = new Label(String.valueOf((char) ('A' + r)));
            rowLabel.getStyleClass().add("seat-row-label");
            grid.add(rowLabel, 0, r + 1);

            for (int c = 0; c < cols; c++) {
                Seat seat = seats[r][c];
                Button seatButton = new Button(seat.getSeatNumber());
                seatButton.setAccessibleText("Seat " + seat.getSeatNumber());
                seatButtons[r][c] = seatButton;
                updateSeatStyle(seatButton, seat.getStatus());

                // Recheck authoritative booking state, then toggle only between
                // AVAILABLE and the page-local SELECTED state.
                seatButton.setOnAction(e -> {
                    if (BookingUtils.isBooked(showtime, seat)) {
                        seat.setStatus(Seat.Status.BOOKED);
                        updateSeatStyle(seatButton, Seat.Status.BOOKED);
                        new Alert(Alert.AlertType.INFORMATION,
                                "Seat " + seat.getSeatNumber() + " has already been booked.").show();
                        return;
                    }
                    if (selectedSeats.contains(seat)) {
                        selectedSeats.remove(seat);
                        seat.setStatus(Seat.Status.AVAILABLE);
                    } else {
                        selectedSeats.add(seat);
                        seat.setStatus(Seat.Status.SELECTED);
                    }
                    updateSeatStyle(seatButton, seat.getStatus());
                    updatePriceDisplay();
                });

                grid.add(seatButton, c + 1, r + 1);
            }
        }

        HBox legend = new HBox(18);
        legend.setAlignment(Pos.CENTER);
        legend.getChildren().addAll(
                createLegend("Available", "seat-available"),
                createLegend("Selected", "seat-selected"),
                createLegend("Booked", "seat-booked"));

        left.getChildren().addAll(title, meta, screenBox, grid, legend);

        /* ================= Larger information card ================= */
        VBox summary = new VBox(12);
        summary.getStyleClass().addAll("card", "seat-summary-card");
        summary.setPrefWidth(330);
        summary.setMinWidth(285);
        summary.setMaxWidth(340);
        summary.setPrefHeight(520);
        summary.setPadding(new Insets(24, 26, 24, 26));

        Label sTitle = new Label("YOUR SELECTION");
        sTitle.getStyleClass().add("section-title");
        sTitle.setStyle("-fx-padding: 0 0 4 0;");

        summary.getChildren().add(sTitle);
        summary.getChildren().add(detailRow("Movie", showtime.getMovie().getTitle()));
        summary.getChildren().add(detailRow("Hall", showtime.getHall().getName()));
        summary.getChildren().add(detailRow("Time", showtime.getTime().format(SHOWTIME_FORMAT)));

        Label seatsLabel = new Label("SEATS");
        seatsLabel.getStyleClass().add("field-label");
        seatTagFlow = new FlowPane(7, 7);
        seatTagFlow.setPrefHeight(78);

        lblSeatCount = new Label("Selected: 0 seat");
        lblSeatCount.getStyleClass().add("muted-text");

        lblTotalPrice = new Label(String.format("Total: RM %.2f", 0.00));
        lblTotalPrice.getStyleClass().add("price-text");

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // Continue commits the complete set atomically; on failure the page removes
        // newly unavailable seats and redraws the summary before asking for another choice.
        Button btnNext = new Button("Continue  →");
        btnNext.getStyleClass().add("button-full");
        btnNext.setOnAction(e -> {
            if (selectedSeats.isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Please select at least one seat first.").show();
                return;
            }
            if (BookingUtils.bookSeats(showtime, new ArrayList<>(selectedSeats))) {
                session.setSelectedSeats(new ArrayList<>(selectedSeats));
                app.navigateTo(new PricePage(app).getRoot());
            } else {
                selectedSeats.removeIf(seat -> BookingUtils.isBooked(showtime, seat));
                refreshSeatButtons(seatMap);
                updatePriceDisplay();
                new Alert(Alert.AlertType.ERROR,
                        "One or more seats have already been booked. Please select another seat.").show();
            }
        });

        // Leaving before commit clears temporary SELECTED states from both model and session.
        Button btnBack = new Button("←  Back to Movie");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> {
            for (Seat seat : selectedSeats) {
                if (seat.getStatus() == Seat.Status.SELECTED) {
                    seat.setStatus(Seat.Status.AVAILABLE);
                }
            }
            session.setSelectedSeats(new ArrayList<>());
            app.navigateTo(new MoviePage(app).getRoot());
        });

        summary.getChildren().addAll(seatsLabel, seatTagFlow, lblSeatCount, lblTotalPrice,
                spacer, btnNext, btnBack);

        body.getChildren().addAll(left, summary);
        StackPane bodyWrap = new StackPane(body);
        bodyWrap.setAlignment(Pos.TOP_CENTER);
        center.getChildren().add(bodyWrap);
        root.setCenter(Responsive.wrapScroll(center, -1));

        // Restore seats only when they belong to this exact showtime map.
        for (Seat saved : session.getSelectedSeats()) {
            int r = saved.getRow();
            int c = saved.getCol();
            if (r >= 0 && r < seats.length && c >= 0 && c < seats[r].length
                    && seats[r][c] == saved && saved.getStatus() == Seat.Status.AVAILABLE) {
                saved.setStatus(Seat.Status.SELECTED);
                selectedSeats.add(saved);
            }
        }
        refreshSeatButtons(seatMap);
        updatePriceDisplay();
    }

    /** Reconciles model status, local selection and every corresponding CSS class. */
    private void refreshSeatButtons(SeatMap seatMap) {
        Seat[][] seats = seatMap.getSeats();
        for (int r = 0; r < seats.length; r++) {
            for (int c = 0; c < seats[r].length; c++) {
                Seat seat = seats[r][c];
                if (selectedSeats.contains(seat) && seat.getStatus() != Seat.Status.BOOKED) {
                    seat.setStatus(Seat.Status.SELECTED);
                } else if (seat.getStatus() == Seat.Status.SELECTED) {
                    seat.setStatus(Seat.Status.AVAILABLE);
                }
                if (seatButtons != null && seatButtons[r][c] != null) {
                    updateSeatStyle(seatButtons[r][c], seat.getStatus());
                }
            }
        }
    }

    /** Creates the compact hall/showtime metadata label above the screen. */
    private Label chip(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("duration-chip");
        label.setStyle("-fx-background-color: rgba(118,48,231,0.35); -fx-font-size: 11.5px;");
        return label;
    }

    /** Creates one aligned row in the live selection summary. */
    private HBox detailRow(String key, String value) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("detail-row");
        Label k = new Label(key);
        k.getStyleClass().add("detail-key");
        k.setPrefWidth(52);
        Label v = new Label(value);
        v.getStyleClass().add("detail-value");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        row.getChildren().addAll(k, v);
        return row;
    }

    /** Maps domain status to exactly one seat CSS class. */
    private void updateSeatStyle(Button button, Seat.Status status) {
        button.getStyleClass().removeAll("seat-available", "seat-selected", "seat-booked");
        if (status == Seat.Status.AVAILABLE) {
            button.getStyleClass().add("seat-available");
        } else if (status == Seat.Status.SELECTED) {
            button.getStyleClass().add("seat-selected");
        } else {
            button.getStyleClass().add("seat-booked");
        }
    }

    /**
     * Recalculates count/price and rebuilds ordered seat tags after every toggle.
     * Sorting by row then column keeps the summary stable regardless of click order.
     */
    private void updatePriceDisplay() {
        int count = selectedSeats.size();
        double total = count * PRICE_PER_SEAT;

        lblSeatCount.setText("Selected: " + count + (count == 1 ? " seat" : " seats"));
        lblTotalPrice.setText(String.format("Total: RM %.2f", total));

        seatTagFlow.getChildren().clear();
        List<Seat> sorted = new ArrayList<>(selectedSeats);
        sorted.sort((a, b) -> a.getRow() != b.getRow()
                ? a.getRow() - b.getRow() : a.getCol() - b.getCol());
        for (Seat seat : sorted) {
            Label tag = new Label(seat.getSeatNumber());
            tag.getStyleClass().add("seat-tag");
            seatTagFlow.getChildren().add(tag);
        }
        if (sorted.isEmpty()) {
            Label empty = new Label("No seats selected yet");
            empty.getStyleClass().add("muted-text");
            seatTagFlow.getChildren().add(empty);
        }
    }

    /** Builds a non-interactive legend sample using the same status style as seats. */
    private HBox createLegend(String text, String style) {
        Button sample = new Button();
        sample.setPrefSize(16, 16);
        sample.setMinSize(16, 16);
        sample.setMaxSize(16, 16);
        sample.getStyleClass().addAll(style, "seat-legend-sample");
        Label label = new Label(text);
        label.getStyleClass().add("muted-text");
        return new HBox(6, sample, label);
    }

    public Pane getRoot() {
        return root;
    }
}
