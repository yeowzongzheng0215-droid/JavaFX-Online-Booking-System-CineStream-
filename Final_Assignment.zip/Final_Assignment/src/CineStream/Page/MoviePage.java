package CineStream.Page;

import CineStream.BannerSlider;
import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.MovieCatalogue;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.UserSession;
import CineStream.Model.MovieData;
import CineStream.Model.Showtime;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Movie and showtime selection page.
 *
 * Catalogue data drives the poster grid and showtime chips. Clicking a poster
 * updates local selection, filters performances, auto-selects the first result
 * and refreshes the summary. Continue commits both choices to UserSession so
 * SeatPage can render the correct banner, hall and independent SeatMap.
 */
public class MoviePage {
    private static final DateTimeFormatter SHOWTIME_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, dd MMM  HH:mm", Locale.ENGLISH);
    private static final DateTimeFormatter SHOWTIME_DAY =
            DateTimeFormatter.ofPattern("EEEE, dd MMM", Locale.ENGLISH);
    private static final DateTimeFormatter SHOWTIME_TIME =
            DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);

    private final MainApp app;
    private final BorderPane root;
    private final List<MovieData> movies;
    private final List<Showtime> showtimes;

    /** Local choices are committed to UserSession only when Continue succeeds. */
    private MovieData selectedMovie;
    private Showtime selectedShowtime;

    /** Maps rendered nodes back to domain objects for selected-card styling. */
    private final Map<VBox, MovieData> movieCardMap = new HashMap<>();
    private final List<Button> chipButtons = new ArrayList<>();
    private final FlowPane chipFlow = new FlowPane(10, 10);

    private final Label lblSummaryMovie;
    private final Label lblSummaryShowtime;

    public MoviePage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "movies"));

        movies = MovieCatalogue.getMovies();
        showtimes = MovieCatalogue.getShowtimes();
        selectedMovie = UserSession.getInstance().getSelectedMovie();

        VBox center = new VBox(0);
        center.getChildren().add(new StepsBar(0));

        // Reuse Home's carousel directly below the progress indicator.  It is
        // part of normal layout flow, so it never overlays the cards below it.
        center.getChildren().add(buildHomeBanner());

        VBox bookingContent = new VBox(24);
        bookingContent.setPadding(new Insets(28, 32, 32, 32));
        bookingContent.setMaxWidth(1240);
        bookingContent.setAlignment(Pos.TOP_CENTER);

        /* ---------------- Poster grid (left) ---------------- */
        VBox movieArea = new VBox(14);
        movieArea.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Choose Your Movie");
        title.getStyleClass().add("title-label");

        GridPane movieCards = new GridPane();
        movieCards.setHgap(18);
        movieCards.setVgap(18);
        movieCards.setAlignment(Pos.CENTER);

        int col = 0;
        int row = 0;
        for (MovieData movie : movies) {
            VBox card = movieCard(movie);
            movieCards.add(card, col, row);
            col++;
            if (col == 3) {
                col = 0;
                row++;
            }
        }
        movieArea.getChildren().addAll(title, movieCards);

        /* ---------------- Current selection (right) ---------------- */
        VBox summary = new VBox(12);
        summary.getStyleClass().addAll("card", "movie-selection-card");
        summary.setPrefWidth(310);
        summary.setMinWidth(285);
        summary.setMaxWidth(310);
        summary.setPrefHeight(410);
        summary.setMaxHeight(410);
        summary.setPadding(new Insets(24));

        Label sTitle = new Label("YOUR SELECTION");
        sTitle.getStyleClass().add("section-title");
        sTitle.setStyle("-fx-padding: 0 0 4 0;");

        Label sMovieLabel = new Label("Movie");
        sMovieLabel.getStyleClass().add("field-label");
        lblSummaryMovie = new Label("—");
        lblSummaryMovie.getStyleClass().add("detail-value");
        lblSummaryMovie.setWrapText(true);

        Label sTimeLabel = new Label("Showtime");
        sTimeLabel.getStyleClass().add("field-label");
        lblSummaryShowtime = new Label("—");
        lblSummaryShowtime.getStyleClass().add("detail-value");
        lblSummaryShowtime.setWrapText(true);

        Region summarySpacer = new Region();
        VBox.setVgrow(summarySpacer, Priority.ALWAYS);

        // Continue is the transaction boundary between local UI state and the
        // shared booking state consumed by SeatPage.
        Button btnNext = new Button("Continue  →");
        btnNext.getStyleClass().add("button-full");
        btnNext.setOnAction(e -> {
            if (selectedMovie == null || selectedShowtime == null) {
                new Alert(Alert.AlertType.WARNING, "Please select a movie and showtime first.").show();
                return;
            }
            UserSession session = UserSession.getInstance();
            session.setSelectedMovie(selectedMovie);
            session.setSelectedShowtime(selectedShowtime);
            app.navigateTo(new SeatPage(app).getRoot());
        });

        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        summary.getChildren().addAll(sTitle, sMovieLabel, lblSummaryMovie,
                sTimeLabel, lblSummaryShowtime, summarySpacer, btnNext, btnBack);

        HBox selectionRow = new HBox(32, movieArea, summary);
        selectionRow.setAlignment(Pos.CENTER);
        selectionRow.setMaxWidth(Double.MAX_VALUE);

        /* ---------------- Showtime section below both columns ---------------- */
        VBox showtimeSection = new VBox(8);
        showtimeSection.setAlignment(Pos.TOP_LEFT);
        showtimeSection.setMaxWidth(1040);

        Label lblShowtime = new Label("Select Showtime");
        lblShowtime.getStyleClass().add("section-title");
        lblShowtime.setStyle("-fx-padding: 0 0 4 0;");

        chipFlow.setPadding(new Insets(2, 0, 0, 0));
        chipFlow.setAlignment(Pos.CENTER_LEFT);
        showtimeSection.getChildren().addAll(lblShowtime, chipFlow);

        bookingContent.getChildren().addAll(selectionRow, showtimeSection);
        StackPane bookingWrap = new StackPane(bookingContent);
        bookingWrap.setAlignment(Pos.TOP_CENTER);

        center.getChildren().addAll(bookingWrap, new Footer(app));
        root.setCenter(Responsive.wrapScroll(center, -1));

        // A Home poster click stores its movie in UserSession, allowing this page
        // to restore the same highlighted card when it is constructed.
        if (selectedMovie != null) {
            selectMovie(selectedMovie);
        } else {
            renderShowtimeChips(new ArrayList<>());
            updateSummary();
        }
    }

    /** Home carousel imagery, in a slightly more compact booking-page height. */
    private BannerSlider buildHomeBanner() {
        List<MovieData> bannerMovies = new ArrayList<>(movies);
        if (selectedMovie != null && bannerMovies.remove(selectedMovie)) {
            bannerMovies.add(0, selectedMovie);
        }

        List<Image> banners = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        for (MovieData movie : bannerMovies) {
            banners.add(ImageStore.banner(movie));
            titles.add(movie.getTitle());
        }
        return new BannerSlider(banners, titles, 420);
    }

    /** Poster card using exactly the same real image assets as Home. */
    private VBox movieCard(MovieData movie) {
        VBox card = new VBox(8);
        card.getStyleClass().addAll("movie-card", "booking-poster-card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPrefWidth(184);
        card.setMinWidth(184);
        card.setMaxWidth(184);
        card.setPadding(new Insets(12));

        StackPane poster = Ui.moviePosterImage(movie, 160, 240, 12);

        Label title = new Label(movie.getTitle());
        title.getStyleClass().add("movie-title-label");
        title.setWrapText(true);
        title.setMaxWidth(160);
        title.setAlignment(Pos.CENTER);

        Label genre = new Label(movie.getGenre() + "  •  " + movie.getDuration() + " min");
        genre.getStyleClass().add("muted-text");
        genre.setWrapText(true);
        genre.setMaxWidth(160);
        genre.setAlignment(Pos.CENTER);

        card.getChildren().addAll(poster, title, genre);
        movieCardMap.put(card, movie);
        card.setOnMouseClicked(e -> selectMovie(movie));
        addHoverScale(card);
        return card;
    }

    /** Creates a chip that owns its Showtime through Node.userData. */
    private Button buildShowtimeChip(Showtime showtime) {
        String text = showtime.getTime().format(SHOWTIME_DAY)
                + "\n" + showtime.getTime().format(SHOWTIME_TIME)
                + "  •  " + showtime.getHall().getName();
        Button chip = new Button(text);
        chip.getStyleClass().add("showtime-chip");
        chip.setWrapText(false);
        chip.setUserData(showtime);
        chip.setOnAction(e -> {
            selectedShowtime = showtime;
            refreshChipSelection();
            updateSummary();
        });
        return chip;
    }

    /** Rebuilds the chip row whenever another movie changes the available set. */
    private void renderShowtimeChips(List<Showtime> available) {
        chipFlow.getChildren().clear();
        chipButtons.clear();

        for (Showtime showtime : available) {
            Button chip = buildShowtimeChip(showtime);
            chipButtons.add(chip);
            chipFlow.getChildren().add(chip);
        }

        if (available.isEmpty()) {
            Label empty = new Label("Select a movie to view available showtimes.");
            empty.getStyleClass().add("muted-text");
            chipFlow.getChildren().add(empty);
        }
        refreshChipSelection();
    }

    /** Keeps chip CSS synchronized with the selected Showtime reference. */
    private void refreshChipSelection() {
        for (Button chip : chipButtons) {
            chip.getStyleClass().remove("showtime-chip-selected");
            if (chip.getUserData() == selectedShowtime) {
                chip.getStyleClass().add("showtime-chip-selected");
            }
        }
    }

    /**
     * Handles a poster click: highlight the card, filter matching performances,
     * choose a useful default and update every dependent UI element.
     */
    private void selectMovie(MovieData movie) {
        selectedMovie = movie;

        for (Map.Entry<VBox, MovieData> entry : movieCardMap.entrySet()) {
            VBox card = entry.getKey();
            if (entry.getValue().equals(movie)) {
                if (!card.getStyleClass().contains("movie-card-selected")) {
                    card.getStyleClass().add("movie-card-selected");
                }
            } else {
                card.getStyleClass().remove("movie-card-selected");
            }
        }

        List<Showtime> available = showtimes.stream()
                .filter(showtime -> showtime.getMovie().equals(movie))
                .collect(Collectors.toList());

        selectedShowtime = available.isEmpty() ? null : available.get(0);
        renderShowtimeChips(available);
        updateSummary();
    }

    /** Mirrors the current local choices in the read-only summary card. */
    private void updateSummary() {
        lblSummaryMovie.setText(selectedMovie == null ? "—" : selectedMovie.getTitle());
        if (selectedShowtime == null) {
            lblSummaryShowtime.setText("—");
        } else {
            lblSummaryShowtime.setText(selectedShowtime.getTime().format(SHOWTIME_FORMAT)
                    + "\n" + selectedShowtime.getHall().getName());
        }
    }

    /** Match Home's poster-card hover animation exactly. */
    private void addHoverScale(Node node) {
        javafx.animation.ScaleTransition hoverIn =
                new javafx.animation.ScaleTransition(javafx.util.Duration.millis(150), node);
        hoverIn.setToX(1.04);
        hoverIn.setToY(1.04);
        javafx.animation.ScaleTransition hoverOut =
                new javafx.animation.ScaleTransition(javafx.util.Duration.millis(150), node);
        hoverOut.setToX(1.0);
        hoverOut.setToY(1.0);
        node.setOnMouseEntered(e -> {
            hoverOut.stop();
            hoverIn.playFromStart();
        });
        node.setOnMouseExited(e -> {
            hoverIn.stop();
            hoverOut.playFromStart();
        });
    }

    public Pane getRoot() {
        return root;
    }
}
