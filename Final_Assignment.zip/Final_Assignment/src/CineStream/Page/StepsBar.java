package CineStream.Page;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;

/**
 * Shared booking progress indicator: Movie -> Seats -> Payment -> Ticket.
 *
 * currentStep determines three visual states: earlier steps are completed, the
 * matching step is active, and later steps remain inactive. Pages pass their
 * workflow index when constructing the component.
 */
public class StepsBar extends HBox {

    private static final String[] STEPS = {"Movie", "Seats", "Payment", "Ticket"};

    public StepsBar(int currentStep) {
        setAlignment(Pos.CENTER);
        setSpacing(0);
        getStyleClass().add("steps-bar");
        setPadding(new Insets(10, 20, 10, 20));

        for (int i = 0; i < STEPS.length; i++) {
            // Numbered state marker.
            Label dot = new Label(String.valueOf(i + 1));
            dot.getStyleClass().add("step-dot");
            // Human-readable step label.
            Label txt = new Label(STEPS[i]);
            txt.getStyleClass().add("step-text");

            if (i == currentStep) {
                dot.getStyleClass().add("step-dot-active");
                txt.getStyleClass().add("step-text-active");
            } else if (i < currentStep) {
                dot.getStyleClass().add("step-dot-done");
                txt.getStyleClass().add("step-text-done");
            }

            HBox item = new HBox(7, dot, txt);
            item.setAlignment(Pos.CENTER);
            getChildren().add(item);

            // Connector inherits completed styling from earlier steps.
            if (i < STEPS.length - 1) {
                Region line = new Region();
                line.setPrefWidth(58);
                // A slim connector keeps the progress indicator light and clean.
                line.setPrefHeight(1);
                line.setMinHeight(1);
                line.setMaxHeight(1);
                line.getStyleClass().add("step-line");
                if (i < currentStep) {
                    line.getStyleClass().add("step-line-done");
                }
                getChildren().add(line);
            }
        }
    }
}
