package CineStream.Page;

import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.UserSession;
import CineStream.UserStore;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.regex.Pattern;

/**
 * Authenticates an existing runtime account.
 *
 * Input is validated locally, credentials are checked by UserStore, and a
 * successful result writes the username to UserSession before routing Home.
 */
public class LoginPage {
    private final MainApp app;
    private final BorderPane root;
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@gmail\\.com$");

    public LoginPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, ""));

        // Build the centred authentication card.
        VBox card = new VBox(14);
        card.getStyleClass().addAll("card", "auth-card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(34, 42, 34, 42));
        card.setPrefWidth(430);
        card.setMaxWidth(430);

        Label kicker = new Label("◆ CINESTREAM MEMBER");
        kicker.getStyleClass().add("muted-text");
        kicker.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");

        Label title = new Label("Welcome Back");
        title.getStyleClass().add("title-label");

        Label sub = new Label("Log in to book your movie tickets");
        sub.getStyleClass().add("subtitle-label");

        // Email
        Label lblEmail = new Label("EMAIL ADDRESS");
        lblEmail.getStyleClass().add("field-label");
        TextField tfEmail = new TextField();
        tfEmail.setPromptText("yourname@gmail.com");
        HBox.setHgrow(tfEmail, Priority.ALWAYS);

        // Password
        Label lblPass = new Label("PASSWORD");
        lblPass.getStyleClass().add("field-label");
        PasswordField pfPassword = new PasswordField();
        pfPassword.setPromptText("Enter your password");

        // Secondary account options sit on one horizontal row.
        HBox optionsRow = new HBox(10);
        optionsRow.setAlignment(Pos.CENTER_LEFT);
        CheckBox chkRemember = new CheckBox("Remember me");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Hyperlink linkForgot = new Hyperlink("Forgot password?");
        linkForgot.setOnAction(e -> new Alert(Alert.AlertType.INFORMATION,
                "Please sign up first if you don't have an account.").show());
        optionsRow.getChildren().addAll(chkRemember, spacer, linkForgot);

        // Validate credentials before creating the logged-in session.
        Button btnLogin = new Button("Sign In");
        btnLogin.getStyleClass().add("button-full");
        btnLogin.setOnAction(e -> {
            String email = tfEmail.getText().trim();
            String password = pfPassword.getText().trim();

            if (!EMAIL_PATTERN.matcher(email).matches()) {
                new Alert(Alert.AlertType.ERROR, "Please enter a valid Gmail address.").show();
                return;
            }
            if (password.isBlank()) {
                new Alert(Alert.AlertType.ERROR, "Password cannot be empty.").show();
                return;
            }
            if (!UserStore.getInstance().validateLogin(email, password)) {
                new Alert(Alert.AlertType.ERROR, "Invalid email or password.").show();
                return;
            }

            UserSession.getInstance().login(email);
            new Alert(Alert.AlertType.INFORMATION, "Login successful. Welcome, " + email).show();
            app.navigateTo(new HomePage(app).getRoot());
        });

        // Separate the primary action from account-navigation links.
        Separator sep = new Separator();

        // Direct new users to the registration page.
        HBox signupRow = new HBox(6);
        signupRow.setAlignment(Pos.CENTER);
        Label noAccount = new Label("Don't have an account?");
        noAccount.getStyleClass().add("muted-text");
        Hyperlink linkSignUp = new Hyperlink("Sign Up");
        linkSignUp.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        linkSignUp.setOnAction(e -> app.navigateTo(new SignUpPage(app).getRoot()));
        signupRow.getChildren().addAll(noAccount, linkSignUp);

        // Return without changing authentication state.
        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        card.getChildren().addAll(kicker, title, sub,
                lblEmail, tfEmail, lblPass, pfPassword,
                optionsRow, btnLogin, sep, signupRow, btnBack);

        // Keep a comfortable gap below the navigation bar.  The supplied
        // popcorn image is blurred behind the form and fades into the
        // original dark-purple background in the lower half.
        VBox pageContent = new VBox(card);
        pageContent.setAlignment(Pos.CENTER);
        pageContent.setPadding(new Insets(38, 24, 44, 24));
        root.setCenter(Ui.blurredBackdrop(
                ImageStore.popcornBackground(),
                Responsive.wrapScrollFill(pageContent, -1)));
    }

    public Pane getRoot() {
        return root;
    }
}
