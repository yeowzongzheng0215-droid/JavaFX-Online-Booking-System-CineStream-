package CineStream.Page;

import CineStream.MainApp;
import CineStream.UserSession;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;

/**
 * Shared top navigation that coordinates page routing and user-session state.
 *
 * Every page constructs a new NavBar and passes its active-page key. Public
 * destinations navigate immediately; booking/history destinations first consult
 * UserSession and redirect unauthenticated users to LoginPage.
 */
public class NavBar extends HBox {

    public NavBar(MainApp app, String activePage) {
        setAlignment(Pos.CENTER_LEFT);
        setSpacing(4);
        setPadding(new Insets(10, 16, 10, 16));
        getStyleClass().add("nav-bar");

        // Brand logo and name.
        javafx.scene.image.ImageView logoImg = CineStream.Ui.logoView(28);

        Label logoText = new Label("CINESTREAM");
        logoText.getStyleClass().add("logo-text");

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);
        spacer1.setMinWidth(8);

        // Internal navigation; protected destinations require authentication.
        Button btnHome = navButton("Home", "home".equals(activePage), e -> app.navigateTo(new HomePage(app).getRoot()));
        Button btnMovies = navButton("Now Showing", "movies".equals(activePage), e -> {
            if (UserSession.getInstance().isLoggedIn()) {
                app.navigateTo(new MoviePage(app).getRoot());
            } else {
                showLoginPrompt(app, "Please log in first to book movie tickets.");
            }
        });
        Button btnHistory = navButton("My Tickets", "history".equals(activePage), e -> {
            if (UserSession.getInstance().isLoggedIn()) {
                app.navigateTo(new BookingHistoryPage(app).getRoot());
            } else {
                showLoginPrompt(app, "Please log in first to view your booking history.");
            }
        });
        Button btnAbout = navButton("About", "about".equals(activePage), e -> app.navigateTo(new AboutPage(app).getRoot()));

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);
        spacer2.setMinWidth(6);

        // Session-aware actions: user/logout when signed in, login/sign-up otherwise.
        if (UserSession.getInstance().isLoggedIn()) {
            Label lblUser = new Label("Hi, " + UserSession.getInstance().getUsername());
            lblUser.getStyleClass().add("user-label");
            lblUser.setMaxWidth(105);
            lblUser.setTextOverrun(javafx.scene.control.OverrunStyle.ELLIPSIS);

            Button btnLogout = new Button("Logout");
            btnLogout.getStyleClass().addAll("button-small", "button-ghost");
            btnLogout.setOnAction(e -> {
                UserSession.getInstance().logout();
                new Alert(Alert.AlertType.INFORMATION, "You have logged out successfully.").show();
                app.navigateTo(new HomePage(app).getRoot());
            });

            getChildren().addAll(logoImg, logoText, spacer1,
                    btnHome, btnMovies, btnHistory, btnAbout,
                    spacer2, lblUser, btnLogout);
        } else {
            Button btnLogin = new Button("Login");
            btnLogin.getStyleClass().addAll("button-small", "button-ghost");
            btnLogin.setOnAction(e -> app.navigateTo(new LoginPage(app).getRoot()));

            Button btnSignUp = new Button("Sign Up");
            btnSignUp.getStyleClass().addAll("button-small");
            btnSignUp.setOnAction(e -> app.navigateTo(new SignUpPage(app).getRoot()));

            getChildren().addAll(logoImg, logoText, spacer1,
                    btnHome, btnMovies, btnHistory, btnAbout,
                    spacer2, btnLogin, btnSignUp);
        }
    }

    /** Creates a navigation button and applies the active-page visual state. */
    private Button navButton(String text, boolean active, javafx.event.EventHandler<javafx.event.ActionEvent> handler) {
        Button b = new Button(text);
        b.getStyleClass().add("nav-button");
        if (active) {
            b.getStyleClass().add("nav-button-active");
        }
        b.setOnAction(handler);
        return b;
    }

    /** Explains the protected route and then continues the interaction on LoginPage. */
    private void showLoginPrompt(MainApp app, String message) {
        new Alert(Alert.AlertType.INFORMATION, message).show();
        app.navigateTo(new LoginPage(app).getRoot());
    }
}
