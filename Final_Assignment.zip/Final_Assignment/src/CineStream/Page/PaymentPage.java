package CineStream.Page;

import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Model.Reservation;
import CineStream.UserSession;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Collects a payment method and finalizes the active booking.
 *
 * The order summary is read from UserSession. Card mode validates local fields;
 * wallet/bank modes show redirect information. On success, doPay creates an
 * immutable Reservation for BookingHistoryPage and routes to TicketPage, which
 * generates the visual e-ticket from the same session.
 */
public class PaymentPage {
    private final MainApp app;
    private final BorderPane root;

    /** Nodes retained as fields because payment-method events toggle/validate them. */
    private final VBox cardFields;
    private final TextField tfCardNo;
    private final TextField tfExpiry;
    private final PasswordField pfCvv;
    private final Label lblPayInfo;

    public PaymentPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "movies"));

        UserSession session = UserSession.getInstance();
        double total = session.getSelectedSeats().size() * 18.0;

        VBox center = new VBox(0);
        center.getChildren().addAll(
                new StepsBar(2),
                new MovieHeroBanner(session.getSelectedMovie()));

        HBox body = new HBox(20);
        // Extra bottom spacing keeps both payment cards clear of the page edge.
        body.setPadding(new Insets(24, 30, 88, 30));
        body.setAlignment(Pos.TOP_CENTER);

        /* ================= Left: payment method and input ================= */
        VBox left = new VBox(12);
        left.getStyleClass().add("card");
        left.setMaxWidth(560);
        HBox.setHgrow(left, Priority.ALWAYS);
        left.setPadding(new Insets(24, 26, 24, 26));

        Label kicker = new Label("◆ SECURE PAYMENT");
        kicker.getStyleClass().add("muted-text");
        kicker.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");

        Label title = new Label("Choose Payment Method");
        title.getStyleClass().add("title-label");
        title.setStyle("-fx-font-size: 21px;");

        ToggleGroup group = new ToggleGroup();

        ToggleButton btnCard = payMethod("Card", "Credit / Debit Card", group);
        ToggleButton btnWallet = payMethod("Wallet", "E-Wallet (Touch n Go / GrabPay)", group);
        ToggleButton btnBank = payMethod("Bank", "Online Banking (FPX)", group);
        btnCard.setSelected(true);

        // Card-specific fields are shown only while Card is the selected method.
        cardFields = new VBox(10);

        Label lblCardNo = new Label("CARD NUMBER");
        lblCardNo.getStyleClass().add("field-label");
        tfCardNo = new TextField();
        tfCardNo.setPromptText("1234 5678 9012 3456");

        HBox cardRow = new HBox(12);
        Label lblExpiry = new Label("EXPIRY");
        lblExpiry.getStyleClass().add("field-label");
        tfExpiry = new TextField();
        tfExpiry.setPromptText("MM/YY");
        tfExpiry.setPrefWidth(110);
        Label lblCvv = new Label("CVV");
        lblCvv.getStyleClass().add("field-label");
        pfCvv = new PasswordField();
        pfCvv.setPromptText("•••");
        pfCvv.setPrefWidth(90);
        cardRow.getChildren().addAll(lblExpiry, tfExpiry, lblCvv, pfCvv);

        cardFields.getChildren().addAll(lblCardNo, tfCardNo, cardRow);

        lblPayInfo = new Label("You will be redirected to your e-wallet app to complete payment.");
        lblPayInfo.getStyleClass().add("muted-text");
        lblPayInfo.setWrapText(true);
        lblPayInfo.setVisible(false);
        lblPayInfo.setManaged(false);

        btnCard.setOnAction(e -> switchMethod(true));
        btnWallet.setOnAction(e -> switchMethod(false));
        btnBank.setOnAction(e -> switchMethod(false));

        left.getChildren().addAll(kicker, title, btnCard, btnWallet, btnBank, cardFields, lblPayInfo);

        /* ================= Right: immutable order summary ================= */
        VBox right = new VBox(10);
        right.getStyleClass().add("card");
        right.setPrefWidth(300);
        right.setMaxWidth(300);
        right.setPadding(new Insets(20, 22, 20, 22));

        Label sTitle = new Label("ORDER SUMMARY");
        sTitle.getStyleClass().add("section-title");
        sTitle.setStyle("-fx-padding: 0 0 4 0;");

        right.getChildren().add(detailRow("Movie", session.getSelectedMovie().getTitle()));
        right.getChildren().add(detailRow("Hall", session.getSelectedShowtime().getHall().getName()));
        right.getChildren().add(detailRow("Time", session.getSelectedShowtime().getTime()
                .format(DateTimeFormatter.ofPattern("EEEE, dd MMM  HH:mm", Locale.ENGLISH))));

        List<String> seatNums = session.getSelectedSeats().stream()
                .map(seat -> seat.getSeatNumber())
                .sorted()
                .collect(Collectors.toList());
        right.getChildren().add(detailRow("Seats", String.join(", ", seatNums)));

        Separator sep = new Separator();
        right.getChildren().add(sep);

        HBox totalRow = new HBox();
        totalRow.setAlignment(Pos.CENTER_LEFT);
        Label totalKey = new Label("TOTAL");
        totalKey.setStyle("-fx-text-fill: #b9a8e0; -fx-font-size: 14px; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label totalVal = new Label(String.format("RM %.2f", total));
        totalVal.getStyleClass().add("price-text");
        totalVal.setStyle("-fx-font-size: 24px;");
        totalRow.getChildren().addAll(totalKey, spacer, totalVal);
        right.getChildren().add(totalRow);

        Region spacer2 = new Region();
        VBox.setVgrow(spacer2, Priority.ALWAYS);
        right.getChildren().add(spacer2);

        Button btnPay = new Button(String.format("Pay RM %.2f  ✓", total));
        btnPay.getStyleClass().add("button-full");
        btnPay.setOnAction(e -> doPay(session, total));

        Button btnBack = new Button("←  Back to Edit");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new ConfirmPage(app).getRoot()));

        right.getChildren().addAll(btnPay, btnBack);

        body.getChildren().addAll(left, right);
        body.setMaxWidth(1000);
        StackPane bodyWrap = new StackPane(body);
        bodyWrap.setAlignment(Pos.TOP_CENTER);
        center.getChildren().add(bodyWrap);
        root.setCenter(Responsive.wrapScroll(center, -1));
    }

    /** Creates one mutually exclusive payment-method control. */
    private ToggleButton payMethod(String icon, String text, ToggleGroup group) {
        ToggleButton b = new ToggleButton(icon + "    " + text);
        b.getStyleClass().add("pay-method");
        b.setToggleGroup(group);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setPrefWidth(500);
        b.setAlignment(Pos.CENTER_LEFT);
        return b;
    }

    /**
     * Sets both visible and managed: hidden controls also leave the layout, so
     * wallet/bank information occupies the correct space without blank gaps.
     */
    private void switchMethod(boolean cardMode) {
        cardFields.setVisible(cardMode);
        cardFields.setManaged(cardMode);
        lblPayInfo.setVisible(!cardMode);
        lblPayInfo.setManaged(!cardMode);
    }

    /** Validates the active method, persists history, then opens the e-ticket. */
    private void doPay(UserSession session, double total) {
        // Validate card input before creating the reservation and e-ticket.
        String cardNo = tfCardNo.getText().trim().replace(" ", "");
        String expiry = tfExpiry.getText().trim();
        String cvv = pfCvv.getText().trim();

        if (cardFields.isVisible()) {
            if (!cardNo.matches("\\d{16}")) {
                new Alert(Alert.AlertType.ERROR, "Please enter a valid 16-digit card number.").show();
                return;
            }
            if (!expiry.matches("\\d{2}/\\d{2}")) {
                new Alert(Alert.AlertType.ERROR, "Please enter expiry in MM/YY format.").show();
                return;
            }
            if (!cvv.matches("\\d{3}")) {
                new Alert(Alert.AlertType.ERROR, "Please enter a valid 3-digit CVV.").show();
                return;
            }
        }

        // Reservation copies the seat list so future session changes cannot alter history.
        BookingHistoryPage.ALL_BOOKINGS.add(new Reservation(
                session.getUsername(),
                session.getSelectedMovie(),
                session.getSelectedShowtime(),
                session.getSelectedSeats()
        ));

        new Alert(Alert.AlertType.INFORMATION,
                String.format("Payment of RM %.2f successful! Generating your e-ticket...", total)).show();
        app.navigateTo(new TicketPage(app).getRoot());
    }

    /** Creates one key/value line in the order summary. */
    private HBox detailRow(String key, String value) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("detail-row");
        Label k = new Label(key);
        k.getStyleClass().add("detail-key");
        k.setPrefWidth(46);
        Label v = new Label(value);
        v.getStyleClass().add("detail-value");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        row.getChildren().addAll(k, v);
        return row;
    }

    public Pane getRoot() {
        return root;
    }
}
