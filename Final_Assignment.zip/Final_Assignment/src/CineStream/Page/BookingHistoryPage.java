package CineStream.Page;

import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.UserSession;
import CineStream.Model.ReceiptGenerator;
import CineStream.Model.Reservation;
import CineStream.Model.Ticket;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Displays completed reservations for the currently logged-in member.
 *
 * PaymentPage appends Reservation objects to ALL_BOOKINGS. This page filters
 * that shared runtime list by UserSession username, renders either an empty
 * state or booking cards, and can reconstruct a text e-ticket for any record.
 */
public class BookingHistoryPage {
    private static final DateTimeFormatter SHOWTIME_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, dd MMM  HH:mm", Locale.ENGLISH);
    private static final DateTimeFormatter BOOKED_FORMAT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm", Locale.ENGLISH);

    private final MainApp app;
    private final BorderPane root;

    /** Runtime booking repository populated only after PaymentPage succeeds. */
    public static final List<Reservation> ALL_BOOKINGS = new ArrayList<>();

    public BookingHistoryPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "history"));

        String currentUser = UserSession.getInstance().getUsername();

        // The page VBox fills at least the viewport.  The growing spacer below
        // the content pushes Footer to the true bottom on short/empty pages.
        VBox page = new VBox(0);
        VBox body = new VBox(14);
        body.setPadding(new Insets(32, 24, 38, 24));
        body.setAlignment(Pos.TOP_CENTER);

        VBox inner = new VBox(14);
        inner.setMaxWidth(920);
        inner.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("My Booking History");
        title.getStyleClass().add("title-label");

        Label sub = new Label("All your confirmed bookings");
        sub.getStyleClass().add("subtitle-label");
        inner.getChildren().addAll(title, sub);

        // Keep accounts isolated even though the demo repository is shared in memory.
        List<Reservation> mine = ALL_BOOKINGS.stream()
                .filter(reservation -> reservation.getUsername().equals(currentUser))
                .collect(Collectors.toList());

        // Render a call-to-action for new members, otherwise one card per record.
        if (mine.isEmpty()) {
            VBox empty = new VBox(12);
            empty.getStyleClass().add("card");
            empty.setAlignment(Pos.CENTER);
            empty.setMaxWidth(Double.MAX_VALUE);
            empty.setPadding(new Insets(40, 30, 40, 30));

            Label icon = new Label("▶");
            icon.setStyle("-fx-font-size: 34px;");

            Label message = new Label("No bookings yet");
            message.getStyleClass().add("section-title");
            message.setStyle("-fx-padding: 0;");

            Label hint = new Label("Book your first movie ticket and it will appear here.");
            hint.getStyleClass().add("muted-text");

            Button btnBook = new Button("Browse Movies  →");
            btnBook.getStyleClass().add("button-full");
            btnBook.setPrefWidth(220);
            btnBook.setOnAction(e -> app.navigateTo(new MoviePage(app).getRoot()));

            empty.getChildren().addAll(icon, message, hint, btnBook);
            inner.getChildren().add(empty);
        } else {
            for (Reservation reservation : mine) {
                inner.getChildren().add(historyCard(reservation));
            }
        }

        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setPrefWidth(260);
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        HBox backWrap = new HBox(btnBack);
        backWrap.setAlignment(Pos.CENTER);
        inner.getChildren().add(backWrap);
        body.getChildren().add(inner);

        Region footerPush = new Region();
        VBox.setVgrow(footerPush, Priority.ALWAYS);
        page.getChildren().addAll(body, footerPush, new Footer(app));

        root.setCenter(Ui.blurredBackdrop(
                ImageStore.popcornBackground(),
                Responsive.wrapScrollFill(page, -1)));
    }

    /** Builds one booking row with seat tags and a record-specific ticket action. */
    private HBox historyCard(Reservation reservation) {
        HBox card = new HBox(16);
        card.getStyleClass().add("history-card");
        card.setMinWidth(480);
        card.setMaxWidth(Double.MAX_VALUE);
        card.setAlignment(Pos.CENTER_LEFT);

        VBox left = new VBox(5);
        HBox.setHgrow(left, Priority.ALWAYS);

        Label movie = new Label(reservation.getMovie().getTitle());
        movie.getStyleClass().add("movie-title-label");
        movie.setStyle("-fx-font-size: 15px;");

        Label meta = new Label(reservation.getShowtime().getHall().getName()
                + "  •  " + reservation.getShowtime().getTime().format(SHOWTIME_FORMAT));
        meta.getStyleClass().add("muted-text");

        FlowPane seatTags = new FlowPane(6, 6);
        for (var seat : reservation.getSeats()) {
            Label tag = new Label(seat.getSeatNumber());
            tag.getStyleClass().add("seat-tag");
            tag.setStyle("-fx-background-color: rgba(118,48,231,0.45); -fx-font-size: 10.5px;");
            seatTags.getChildren().add(tag);
        }

        Label bookedOn = new Label("Booked on " + reservation.getBookTime().format(BOOKED_FORMAT));
        bookedOn.getStyleClass().add("muted-text");
        bookedOn.setStyle("-fx-font-size: 10.5px;");

        left.getChildren().addAll(movie, meta, seatTags, bookedOn);

        Button btnView = new Button("View E-Ticket");
        btnView.getStyleClass().add("button-small");
        btnView.setOnAction(e -> showTicket(reservation));

        card.getChildren().addAll(left, btnView);
        return card;
    }

    /**
     * Rebuilds a Ticket snapshot from history without changing UserSession, then
     * displays its plain-text form in a modal information dialog.
     */
    private void showTicket(Reservation reservation) {
        Ticket ticket = new Ticket(
                "CS-HIS-" + Math.abs(reservation.hashCode()) % 100000000,
                reservation.getUsername(),
                reservation.getMovie(),
                reservation.getShowtime(),
                reservation.getSeats(),
                ReceiptGenerator.PRICE_PER_SEAT);
        Alert alert = new Alert(Alert.AlertType.INFORMATION, ticket.getTicketText());
        alert.setHeaderText(reservation.getMovie().getTitle() + "  —  E-Ticket");
        alert.setTitle("E-Ticket");
        alert.show();
    }

    public Pane getRoot() {
        return root;
    }
}
