package CineStream.Page;

import CineStream.MainApp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

/**
 * Optional legacy date-selection step.
 *
 * The current catalogue stores today's showtimes directly, but this page remains
 * available to demonstrate DatePicker validation and navigation into MoviePage.
 */
public class DatePage {
    private final MainApp app;
    private final BorderPane root;

    public DatePage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, ""));

        VBox card = new VBox(12);
        card.getStyleClass().add("card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(30, 42, 30, 42));
        card.setPrefWidth(400);
        card.setMaxWidth(400);

        Label title = new Label("Select Screening Date");
        title.getStyleClass().add("title-label");

        Label sub = new Label("Pick a date for your movie");
        sub.getStyleClass().add("subtitle-label");

        DatePicker datePicker = new DatePicker();
        datePicker.setMaxWidth(Double.MAX_VALUE);
        datePicker.setPromptText("dd/MM/yyyy");

        // Do not leave this page until the DatePicker contains a value.
        Button btnNext = new Button("Confirm Date  →");
        btnNext.getStyleClass().add("button-full");
        btnNext.setOnAction(e -> {
            if (datePicker.getValue() == null) {
                javafx.scene.control.Alert alert =
                        new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.WARNING,
                                "Please pick a date first.");
                alert.show();
                return;
            }
            app.navigateTo(new MoviePage(app).getRoot());
        });

        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        card.getChildren().addAll(title, sub, datePicker, btnNext, btnBack);

        VBox wrap = new VBox(card);
        wrap.setAlignment(Pos.CENTER);
        root.setCenter(wrap);
    }

    public Pane getRoot() {
        return root;
    }
}
