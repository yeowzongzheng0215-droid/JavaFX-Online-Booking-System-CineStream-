package CineStream.Page;

import CineStream.MainApp;
import CineStream.UserSession;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * Shared site footer containing brand, contact, quick-link and social sections.
 * Used by HomePage, MoviePage (Now Showing) and BookingHistoryPage (My Tickets).
 */
public class Footer extends VBox {

    private static final double CAP = 1400;

    public Footer(MainApp app) {
        super(0);
        getStyleClass().add("footer");
        setMaxWidth(Double.MAX_VALUE);   // Allow the parent layout to stretch the footer across the viewport.

        HBox cols = new HBox(36);
        cols.setPadding(new Insets(38, 40, 30, 40));
        cols.setMaxWidth(CAP);
        cols.setAlignment(Pos.TOP_LEFT);

        /* ---------- Brand summary ---------- */
        VBox brand = new VBox(10);
        HBox.setHgrow(brand, Priority.ALWAYS);

        HBox logoRow = new HBox(10);
        logoRow.setAlignment(Pos.CENTER_LEFT);
        javafx.scene.image.ImageView logoImg = CineStream.Ui.logoView(30);
        Label logoText = new Label("CINESTREAM");
        logoText.getStyleClass().add("logo-text");
        logoRow.getChildren().addAll(logoImg, logoText);

        Label desc = new Label("Your favourite online movie booking platform. "
                + "Book tickets, pick your seats and get instant e-tickets.");
        desc.getStyleClass().add("footer-text");
        desc.setWrapText(true);
        desc.setMaxWidth(340);
        brand.getChildren().addAll(logoRow, desc);

        /* ---------- Contact details ---------- */
        VBox contact = new VBox(8);
        Label cTitle = new Label("CONTACT US");
        cTitle.getStyleClass().add("footer-title");
        contact.getChildren().addAll(cTitle,
                footerText("•  No. 12, Jalan Panggung, Bukit Bintang,\n     50100 Kuala Lumpur, Malaysia"),
                footerText("•  +60 3-2718 8888"),
                footerText("•  support@cinestream.my"),
                footerText("•  Mon – Sun · 10:00 – 22:00"));

        /* ---------- Internal quick links ---------- */
        VBox links = new VBox(8);
        Label lTitle = new Label("QUICK LINKS");
        lTitle.getStyleClass().add("footer-title");
        links.getChildren().addAll(lTitle,
                footerLink(app, "Home", () -> app.navigateTo(new HomePage(app).getRoot())),
                footerLink(app, "Now Showing", () -> openMembersOnly(app,
                        "Please log in first to book movie tickets.",
                        () -> app.navigateTo(new MoviePage(app).getRoot()))),
                footerLink(app, "My Tickets", () -> openMembersOnly(app,
                        "Please log in first to view your booking history.",
                        () -> app.navigateTo(new BookingHistoryPage(app).getRoot()))),
                footerLink(app, "About", () -> app.navigateTo(new AboutPage(app).getRoot())));

        /* ---------- External social links ---------- */
        VBox social = new VBox(8);
        Label sTitle = new Label("FOLLOW US");
        sTitle.getStyleClass().add("footer-title");
        social.getChildren().addAll(sTitle,
                socialLink(app, "Facebook", "https://www.facebook.com/CineStream"),
                socialLink(app, "Instagram", "https://www.instagram.com/CineStream"),
                socialLink(app, "Twitter / X", "https://x.com/CineStream"),
                socialLink(app, "YouTube", "https://www.youtube.com/@CineStream"));

        cols.getChildren().addAll(brand, contact, links, social);

        /* ---------- Copyright strip ---------- */
        Separator sep = new Separator();
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setPadding(new Insets(14, 20, 16, 20));
        Label copyright = new Label("© 2026 CineStream Sdn. Bhd.  •  All rights reserved  •  Powered by JavaFX");
        copyright.getStyleClass().add("footer-bottom");
        bottom.getChildren().add(copyright);

        StackPane colsWrap = new StackPane(cols);
        colsWrap.setAlignment(Pos.TOP_CENTER);

        getChildren().addAll(colsWrap, sep, bottom);
    }

    /** Applies footer typography to static contact text. */
    private Label footerText(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("footer-text");
        return l;
    }

    /** Wraps an internal page-routing action in a consistently styled hyperlink. */
    private Hyperlink footerLink(MainApp app, String text, Runnable onAction) {
        Hyperlink l = new Hyperlink(text);
        l.getStyleClass().add("footer-link");
        l.setOnAction(e -> onAction.run());
        return l;
    }

    /** Uses JavaFX HostServices to open an external social URL in the system browser. */
    private Hyperlink socialLink(MainApp app, String name, String url) {
        Hyperlink l = new Hyperlink(name);
        l.getStyleClass().add("footer-link");
        l.setOnAction(e -> app.host().showDocument(url));
        return l;
    }

    /** Apply the same authentication guard used by the top navigation bar. */
    private void openMembersOnly(MainApp app, String message, Runnable destination) {
        if (UserSession.getInstance().isLoggedIn()) {
            destination.run();
            return;
        }
        new Alert(Alert.AlertType.INFORMATION, message).show();
        app.navigateTo(new LoginPage(app).getRoot());
    }
}
