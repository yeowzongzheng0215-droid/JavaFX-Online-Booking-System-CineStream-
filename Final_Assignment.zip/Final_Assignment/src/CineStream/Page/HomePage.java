package CineStream.Page;

import CineStream.BannerSlider;
import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.MovieCatalogue;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.UserSession;
import CineStream.Model.MovieData;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

/**
 * Home page structure from top to bottom:
 *   1. Shared navigation bar
 *   2. Compact member action cards
 *   3. Now Showing carousel and poster grid
 *   4. Full footer with contact and social links
 *
 * The page reads UserSession to choose guest/member actions and MovieCatalogue
 * to build both the carousel and cards. Selecting a poster stores the movie in
 * UserSession so MoviePage can preselect the same title.
 */
public class HomePage {
    private final MainApp app;
    private final BorderPane root;
    private static final double SECTION_CAP = 1400; // maximum width for sections other than the full-width banner

    public HomePage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "home"));

        VBox content = new VBox(0);

        content.getChildren().addAll(
                buildTopStrip(),
                buildNowShowing(),
                new Footer(app)
        );

        // Keep the page full width so the carousel can fill the viewport.
        root.setCenter(Responsive.wrapScroll(content, -1));
    }

    /* =================================================================
       Member greeting and compact action cards
       ================================================================= */
    private Region buildTopStrip() {
        VBox strip = new VBox(12);
        strip.setPadding(new Insets(22, 40, 10, 40));

        HBox cards = new HBox(16);
        cards.setAlignment(Pos.CENTER);

        if (UserSession.getInstance().isLoggedIn()) {
            Label greeting = new Label("◆  WELCOME BACK, " + UserSession.getInstance().getUsername().toUpperCase());
            greeting.getStyleClass().add("home-kicker");

            cards.getChildren().addAll(
                    actionCard("▶", "Book Now", "Browse movies & grab your seats",
                            () -> app.navigateTo(new MoviePage(app).getRoot())),
                    actionCard("★", "My Tickets", "View your booking history",
                            () -> app.navigateTo(new BookingHistoryPage(app).getRoot()))
            );
            strip.getChildren().addAll(greeting, cards);
        } else {
            Label greeting = new Label("◆  CREATE AN ACCOUNT TO START BOOKING");
            greeting.getStyleClass().add("home-kicker");

            cards.getChildren().addAll(
                    actionCard("◈", "Login", "Member? Sign in to continue",
                            () -> app.navigateTo(new LoginPage(app).getRoot())),
                    actionCard("✚", "Sign Up", "New here? Register for free",
                            () -> app.navigateTo(new SignUpPage(app).getRoot()))
            );
            strip.getChildren().addAll(greeting, cards);
        }

        return centerSection(strip, SECTION_CAP);
    }

    /** Creates a fully clickable shortcut card and delegates its destination as a Runnable. */
    private HBox actionCard(String icon, String title, String sub, Runnable onAction) {
        HBox card = new HBox(14);
        card.getStyleClass().add("action-card");
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(14, 20, 14, 20));
        card.setMaxWidth(Double.MAX_VALUE);
        card.setPrefHeight(86);
        card.setMinHeight(86);
        HBox.setHgrow(card, Priority.ALWAYS);
        card.setCursor(Cursor.HAND);

        StackPane iconBox = new StackPane(new Label(icon));
        iconBox.getStyleClass().add("action-icon");
        iconBox.setPrefSize(44, 44);

        VBox txt = new VBox(3);
        Label t = new Label(title);
        t.getStyleClass().add("action-title");
        Label s = new Label(sub);
        s.getStyleClass().add("action-sub");
        txt.getChildren().addAll(t, s);

        // The arrow is a real button while the complete card remains clickable.
        Button arrow = new Button("→");
        arrow.getStyleClass().add("action-arrow");
        arrow.setOnAction(e -> {
            e.consume();
            onAction.run();
        });

        card.getChildren().addAll(iconBox, txt, arrow);
        card.setOnMouseClicked(e -> onAction.run());
        addHoverScale(card);
        return card;
    }

    /* =================================================================
       Now Showing carousel and poster grid
       ================================================================= */
    private Region buildNowShowing() {
        VBox sec = new VBox(0);

        List<MovieData> movies = MovieCatalogue.getMovies();

        // Section heading and live movie count.
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(16, 40, 14, 40));
        header.setMaxWidth(SECTION_CAP);
        Label title = new Label("NOW SHOWING");
        title.getStyleClass().add("section-title");
        title.setStyle("-fx-font-size: 21px; -fx-padding: 0;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label count = new Label(movies.size() + " movies now in cinemas");
        count.getStyleClass().add("home-kicker");
        header.getChildren().addAll(title, spacer, count);

        // Build the full-width carousel from catalogue banner assets.
        List<Image> banners = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        for (MovieData m : movies) {
            banners.add(ImageStore.banner(m));
            titles.add(m.getTitle());
        }
        BannerSlider slider = new BannerSlider(banners, titles);

        // Build the responsive two-row poster grid.
        VBox gridWrap = new VBox();
        gridWrap.setPadding(new Insets(22, 40, 8, 40));
        gridWrap.setMaxWidth(SECTION_CAP);

        GridPane grid = new GridPane();
        grid.setHgap(28);                    // horizontal gap between cards
        grid.setVgap(28);                    // vertical gap between cards
        grid.setAlignment(Pos.CENTER);       // centre the complete poster group
        grid.setMaxWidth(Double.MAX_VALUE);
        int col = 0, row = 0;
        for (MovieData m : movies) {
            VBox card = posterCard(m);
            grid.add(card, col, row);
            col++;
            if (col == 3) {
                col = 0;
                row++;
            }
        }
        gridWrap.getChildren().add(grid);

        // Heading/grid are capped and centred; the carousel remains full width.
        StackPane headWrap = new StackPane(header);
        headWrap.setAlignment(Pos.TOP_CENTER);
        StackPane gridCenter = new StackPane(gridWrap);
        gridCenter.setAlignment(Pos.TOP_CENTER);

        sec.getChildren().addAll(headWrap, slider, gridCenter);
        return sec;
    }

    /** Builds one catalogue card whose image and metadata come from the same MovieData. */
    private VBox posterCard(MovieData m) {
        VBox card = new VBox(10);
        card.getStyleClass().add("movie-card");
        // Fixed portrait-card width avoids unwanted black space around posters.
        card.setPrefWidth(252);
        card.setMinWidth(252);
        card.setMaxWidth(252);
        card.setPadding(new Insets(12));
        card.setCursor(Cursor.HAND);
        addHoverScale(card);   // Home-style hover enlargement

        // Real poster shared by Home, Now Showing and Ticket.
        StackPane posterBox = Ui.moviePosterImage(m, 228, 342, 14);

        Label t = new Label(m.getTitle());
        t.getStyleClass().add("movie-title-label");
        t.setWrapText(true);

        Label g = new Label(m.getGenre() + "  •  " + m.getDuration() + " min");
        g.getStyleClass().add("muted-text");

        Button btnBook = new Button("Book Now  →");
        btnBook.getStyleClass().addAll("button-full", "button-small");
        btnBook.setOnAction(e -> bookMovie(m));

        card.getChildren().addAll(posterBox, t, g, btnBook);
        card.setOnMouseClicked(e -> bookMovie(m));
        return card;
    }

    /** Enlarges a card by 4% on hover and restores it when the pointer leaves. */
    private void addHoverScale(Node n) {
        javafx.animation.ScaleTransition in =
                new javafx.animation.ScaleTransition(javafx.util.Duration.millis(150), n);
        in.setToX(1.04);
        in.setToY(1.04);
        javafx.animation.ScaleTransition out =
                new javafx.animation.ScaleTransition(javafx.util.Duration.millis(150), n);
        out.setToX(1.0);
        out.setToY(1.0);
        n.setOnMouseEntered(e -> in.playFromStart());
        n.setOnMouseExited(e -> out.playFromStart());
    }

    /**
     * Starts the booking interaction for a poster. Members continue to MoviePage;
     * guests see an explanation and are redirected to authenticate first.
     */
    private void bookMovie(MovieData m) {
        UserSession.getInstance().setSelectedMovie(m);
        if (UserSession.getInstance().isLoggedIn()) {
            app.navigateTo(new MoviePage(app).getRoot());
        } else {
            new Alert(Alert.AlertType.INFORMATION, "Please log in first to book movie tickets.").show();
            app.navigateTo(new LoginPage(app).getRoot());
        }
    }

    private StackPane centerSection(Region inner, double cap) {
        if (cap > 0) inner.setMaxWidth(cap);
        StackPane wrap = new StackPane(inner);
        wrap.setAlignment(Pos.TOP_CENTER);
        return wrap;
    }

    public Pane getRoot() {
        return root;
    }
}
