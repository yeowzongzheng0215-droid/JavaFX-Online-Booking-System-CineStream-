package CineStream.Page;

import CineStream.MainApp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * Legacy information-page variant retained for compatibility with the original
 * assignment flow. AboutPage is the active navigation destination, while this
 * class can still be instantiated without affecting shared session state.
 */
public class CinemaPage {
    private final MainApp app;
    private final BorderPane root;

    public CinemaPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "about"));

        VBox card = new VBox(14);
        card.getStyleClass().add("card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(32, 44, 32, 44));
        card.setPrefWidth(600);
        card.setMaxWidth(600);

        javafx.scene.image.ImageView logoImg = CineStream.Ui.logoView(48);

        Label title = new Label("About CineStream System");
        title.getStyleClass().add("title-label");
        title.setStyle("-fx-font-size: 21px;");

        Label content = new Label(
                "CineStream is a professional cinema ticket booking system developed using JavaFX.\n\n"
                        + "Core Features:\n"
                        + "• User registration and secure login\n"
                        + "• Browse available movies and screening schedules\n"
                        + "• Interactive seat selection with real-time status updates\n"
                        + "• Automatic fare calculation and payment processing\n"
                        + "• Digital ticket generation and viewing\n"
                        + "• Booking history management\n\n"
                        + "Version: 1.0.0\n"
                        + "Platform: JavaFX");
        content.setWrapText(true);
        content.getStyleClass().add("normal-text");

        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        card.getChildren().addAll(logoImg, title, content, btnBack);

        VBox wrap = new VBox(card);
        wrap.setAlignment(Pos.CENTER);
        root.setCenter(wrap);
    }

    public Pane getRoot() {
        return root;
    }
}
