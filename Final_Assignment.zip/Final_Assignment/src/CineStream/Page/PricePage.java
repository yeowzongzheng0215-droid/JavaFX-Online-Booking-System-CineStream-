package CineStream.Page;

import CineStream.BookingUtils;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.UserSession;
import CineStream.Model.ReceiptGenerator;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * First payment-flow screen: booking and price review.
 *
 * SeatPage reaches this page only after BookingUtils has locked the chosen seats.
 * Continue preserves those locks for ConfirmPage, while Back releases them before
 * SeatPage restores the same coordinates as editable selections.
 */
public class PricePage {
    private static final DateTimeFormatter SHOWTIME_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy  HH:mm", Locale.ENGLISH);

    private final MainApp app;
    private final BorderPane root;

    public PricePage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "movies"));

        // Calculate from shared session state and the one central unit price.
        UserSession session = UserSession.getInstance();
        int seats = session.getSelectedSeats().size();
        double unitPrice = ReceiptGenerator.PRICE_PER_SEAT;
        double total = seats * unitPrice;

        VBox center = new VBox(0);
        center.getChildren().addAll(
                new StepsBar(2),
                new MovieHeroBanner(session.getSelectedMovie()));

        VBox card = new VBox(10);
        card.getStyleClass().add("card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(28, 40, 28, 40));
        card.setPrefWidth(480);
        card.setMaxWidth(480);

        Label kicker = new Label("◆ BOOKING SUMMARY");
        kicker.getStyleClass().add("muted-text");
        kicker.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");

        Label title = new Label("Review Your Booking");
        title.getStyleClass().add("title-label");

        card.getChildren().add(detailRow("Movie", session.getSelectedMovie().getTitle()));
        card.getChildren().add(detailRow("Hall", session.getSelectedShowtime().getHall().getName()));
        card.getChildren().add(detailRow("Time", session.getSelectedShowtime().getTime()
                .format(SHOWTIME_FORMAT)));

        List<String> seatNums = session.getSelectedSeats().stream()
                .map(seat -> seat.getSeatNumber())
                .sorted()
                .collect(Collectors.toList());
        card.getChildren().add(detailRow("Seats", String.join(", ", seatNums)));

        Separator sep = new Separator();
        card.getChildren().add(sep);
        card.getChildren().add(detailRow("Unit Price", String.format("RM %.2f / seat", unitPrice)));
        card.getChildren().add(detailRow("Number of Seats", String.valueOf(seats)));

        HBox totalRow = new HBox();
        totalRow.setAlignment(Pos.CENTER_LEFT);
        Label totalKey = new Label("TOTAL AMOUNT");
        totalKey.setStyle("-fx-text-fill: #b9a8e0; -fx-font-size: 14px; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label totalVal = new Label(String.format("RM %.2f", total));
        totalVal.getStyleClass().add("price-text");
        totalVal.setStyle("-fx-font-size: 26px;");
        totalRow.getChildren().addAll(totalKey, spacer, totalVal);
        card.getChildren().add(totalRow);

        card.getChildren().add(new Separator());

        Button btnNext = new Button("Continue to Confirmation  →");
        btnNext.getStyleClass().add("button-full");
        btnNext.setOnAction(e -> app.navigateTo(new ConfirmPage(app).getRoot()));

        Button btnBack = new Button("←  Back to Seat Selection");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> {
            // The seats are temporarily locked after Continue.  Release them
            // before editing, then SeatPage restores them as selected.
            BookingUtils.releaseSeats(session.getSelectedShowtime(), session.getSelectedSeats());
            app.navigateTo(new SeatPage(app).getRoot());
        });

        card.getChildren().addAll(btnNext, btnBack);

        VBox wrap = new VBox(card);
        wrap.setAlignment(Pos.CENTER);
        wrap.setPadding(new Insets(28, 24, 86, 24));
        center.getChildren().add(wrap);
        root.setCenter(Responsive.wrapScroll(center, -1));
    }

    /** Creates one aligned row in the receipt-style summary. */
    private HBox detailRow(String key, String value) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("detail-row");
        Label k = new Label(key);
        k.getStyleClass().add("detail-key");
        k.setPrefWidth(140);
        Label v = new Label(value);
        v.getStyleClass().add("detail-value");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        row.getChildren().addAll(k, v);
        return row;
    }

    public Pane getRoot() {
        return root;
    }
}
