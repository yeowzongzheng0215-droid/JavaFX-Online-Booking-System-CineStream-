package CineStream.Page;

import CineStream.ImageStore;
import CineStream.Ui;
import CineStream.Model.MovieData;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;

/**
 * Reusable selected-movie banner for Seats, Payment and Ticket flow pages.
 * The complete banner is shown over a blurred cover layer and its lower half
 * fades into the application's original background colour.
 */
public class MovieHeroBanner extends StackPane {

    public static final double DEFAULT_HEIGHT = 350;

    public MovieHeroBanner(MovieData movie) {
        this(movie, DEFAULT_HEIGHT);
    }

    public MovieHeroBanner(MovieData movie, double height) {
        setPrefHeight(height);
        setMinHeight(height);
        setMaxHeight(height);
        setMinWidth(0);
        setStyle("-fx-background-color: #06050e;");
        getStyleClass().add("selected-movie-banner");

        if (movie != null) {
            // ImageStore resolves the banner from the exact MovieData held in UserSession.
            Image image = ImageStore.banner(movie);

            ImageView blurred = Ui.coverImage(image, widthProperty(), heightProperty());
            blurred.setEffect(new GaussianBlur(20));
            blurred.setOpacity(0.78);

            ImageView foreground = Ui.containImage(image, widthProperty(), heightProperty());

            // This shade is intentionally above both image layers so no clear
            // foreground pixel can escape the dark treatment at the edges.
            Rectangle dim = fillRectangle(Color.rgb(3, 3, 9, 0.22));

            Rectangle bottomFade = fillRectangle(new LinearGradient(
                    0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0.00, Color.rgb(6, 5, 14, 0.02)),
                    new Stop(0.42, Color.rgb(6, 5, 14, 0.05)),
                    new Stop(0.70, Color.rgb(12, 7, 28, 0.62)),
                    new Stop(0.92, Color.rgb(18, 8, 38, 1.00)),
                    new Stop(1.00, Color.rgb(18, 8, 38, 1.00))));

            // A tiny opaque seam guard prevents sub-pixel image rounding from
            // producing a one-pixel bright line at the banner's lower edge.
            Rectangle seamGuard = new Rectangle();
            seamGuard.widthProperty().bind(widthProperty());
            seamGuard.setHeight(4);
            seamGuard.setFill(Color.rgb(18, 8, 38));
            seamGuard.setMouseTransparent(true);
            StackPane.setAlignment(seamGuard, javafx.geometry.Pos.BOTTOM_CENTER);

            getChildren().addAll(blurred, foreground, dim, bottomFade, seamGuard);
        }

        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(widthProperty());
        clip.heightProperty().bind(heightProperty());
        setClip(clip);
    }

    /** Creates a mouse-transparent overlay that always follows banner dimensions. */
    private Rectangle fillRectangle(javafx.scene.paint.Paint paint) {
        Rectangle rectangle = new Rectangle();
        rectangle.widthProperty().bind(widthProperty());
        rectangle.heightProperty().bind(heightProperty());
        rectangle.setFill(paint);
        rectangle.setMouseTransparent(true);
        return rectangle;
    }
}
