package CineStream.Page;

import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Ui;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * Static system-information page.
 *
 * The informational card stays unchanged while Ui.blurredBackdrop composes it
 * over the curtain image. Responsive.wrapScrollFill keeps the card centred and
 * scrollable on short windows.
 */
public class AboutPage {
    private final MainApp app;
    private final BorderPane root;

    public AboutPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "about"));

        // Build one self-contained card so the background remains decorative.
        VBox card = new VBox(14);
        card.getStyleClass().add("card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(34, 46, 34, 46));
        card.setPrefWidth(620);
        card.setMaxWidth(620);

        // Logo
        HBox logoRow = new HBox(12);
        logoRow.setAlignment(Pos.CENTER);
        javafx.scene.image.ImageView logoImg = CineStream.Ui.logoView(52);

        Label brand = new Label("CINESTREAM");
        brand.setStyle("-fx-text-fill: #ffffff; -fx-font-size: 24px; -fx-font-weight: bold;");
        logoRow.getChildren().addAll(logoImg, brand);

        Label title = new Label("About the System");
        title.getStyleClass().add("title-label");
        title.setStyle("-fx-font-size: 20px;");

        Label desc = new Label("CineStream is a professional online movie booking system "
                + "developed with JavaFX. It lets you browse movies, pick showtimes, "
                + "select seats in real time and receive an instant digital e-ticket.");
        desc.getStyleClass().add("normal-text");
        desc.setWrapText(true);

        Label featTitle = new Label("SYSTEM FEATURES");
        featTitle.getStyleClass().add("field-label");
        featTitle.setStyle("-fx-font-size: 13px;");

        VBox feats = new VBox(8);
        feats.getChildren().addAll(
                featureRow("✓", "Secure user registration and login (Gmail)"),
                featureRow("✓", "Browse movies and showtimes across 6 halls"),
                featureRow("✓", "Interactive seat selection with live status"),
                featureRow("✓", "Duplicate-booking prevention"),
                featureRow("✓", "Automatic fare calculation (RM 18 / seat)"),
                featureRow("✓", "Digital e-ticket with barcode"),
                featureRow("✓", "Booking history management")
        );

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Label version = new Label("Version 1.0.0   •   JavaFX   •   Online Movie Booking System");
        version.getStyleClass().add("muted-text");
        version.setStyle("-fx-font-size: 11px;");

        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        card.getChildren().addAll(logoRow, title, desc, featTitle, feats, version, btnBack);

        VBox wrap = new VBox(card);
        wrap.setAlignment(Pos.CENTER);
        wrap.setPadding(new Insets(36, 24, 42, 24));
        // Compose scrollable foreground content over the shared blurred-image layer.
        root.setCenter(Ui.blurredBackdrop(
                ImageStore.curtainBackground(),
                Responsive.wrapScrollFill(wrap, -1)));
    }

    /** Creates a consistently aligned icon/text row for the feature list. */
    private HBox featureRow(String icon, String text) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        Label i = new Label(icon);
        i.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");
        Label t = new Label(text);
        t.getStyleClass().add("normal-text");
        row.getChildren().addAll(i, t);
        return row;
    }

    public Pane getRoot() {
        return root;
    }
}
