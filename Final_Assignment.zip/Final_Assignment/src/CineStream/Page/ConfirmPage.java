package CineStream.Page;

import CineStream.BookingUtils;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.UserSession;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Final review step before collecting payment.
 *
 * All displayed values come from UserSession. Proceed keeps the temporary seat
 * locks and opens PaymentPage; Modify Seats releases only those workflow locks
 * through BookingUtils before returning to SeatPage.
 */
public class ConfirmPage {
    private static final DateTimeFormatter SHOWTIME_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy  HH:mm", Locale.ENGLISH);

    private final MainApp app;
    private final BorderPane root;

    public ConfirmPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, "movies"));

        // Previous pages have already validated and stored the complete selection.
        UserSession session = UserSession.getInstance();
        double total = session.getSelectedSeats().size() * 18.0;

        VBox center = new VBox(0);
        center.getChildren().addAll(
                new StepsBar(2),
                new MovieHeroBanner(session.getSelectedMovie()));

        VBox card = new VBox(10);
        card.getStyleClass().add("card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(28, 40, 28, 40));
        card.setPrefWidth(520);
        card.setMaxWidth(520);

        Label kicker = new Label("◆ CONFIRM BOOKING");
        kicker.getStyleClass().add("muted-text");
        kicker.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");

        Label title = new Label("Confirm Your Booking Details");
        title.getStyleClass().add("title-label");

        card.getChildren().add(detailRow("Customer", session.getUsername()));
        card.getChildren().add(detailRow("Movie", session.getSelectedMovie().getTitle()));
        card.getChildren().add(detailRow("Hall", session.getSelectedShowtime().getHall().getName()));
        card.getChildren().add(detailRow("Showtime", session.getSelectedShowtime().getTime()
                .format(SHOWTIME_FORMAT)));

        List<String> seatNums = session.getSelectedSeats().stream()
                .map(seat -> seat.getSeatNumber())
                .sorted()
                .collect(Collectors.toList());
        card.getChildren().add(detailRow("Seats", String.join(", ", seatNums)));

        card.getChildren().add(new Separator());

        HBox totalRow = new HBox();
        totalRow.setAlignment(Pos.CENTER_LEFT);
        Label totalKey = new Label("TOTAL PAYABLE");
        totalKey.setStyle("-fx-text-fill: #b9a8e0; -fx-font-size: 13.5px; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label totalVal = new Label(String.format("RM %.2f", total));
        totalVal.getStyleClass().add("price-text");
        totalVal.setStyle("-fx-font-size: 24px;");
        totalRow.getChildren().addAll(totalKey, spacer, totalVal);
        card.getChildren().addAll(totalRow, new Separator());

        // Seat locks remain BOOKED while the user proceeds to payment.
        Button btnPay = new Button("Proceed to Payment  →");
        btnPay.getStyleClass().add("button-full");
        btnPay.setOnAction(e -> app.navigateTo(new PaymentPage(app).getRoot()));

        // Editing must release this flow's locks so the same seats can be restored
        // as SELECTED rather than being shown as permanently unavailable.
        Button btnModify = new Button("←  Modify Seats");
        btnModify.getStyleClass().addAll("button-secondary", "button-full");
        btnModify.setOnAction(e -> {
            BookingUtils.releaseSeats(session.getSelectedShowtime(), session.getSelectedSeats());
            app.navigateTo(new SeatPage(app).getRoot());
        });

        card.getChildren().addAll(btnPay, btnModify);

        VBox wrap = new VBox(card);
        wrap.setAlignment(Pos.CENTER);
        wrap.setPadding(new Insets(28, 24, 86, 24));
        center.getChildren().add(wrap);
        root.setCenter(Responsive.wrapScroll(center, -1));
    }

    /* Creates a reusable key/value row for the confirmation card. */
    private HBox detailRow(String key, String value) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("detail-row");
        Label k = new Label(key);
        k.getStyleClass().add("detail-key");
        k.setPrefWidth(92);
        Label v = new Label(value);
        v.getStyleClass().add("detail-value");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        row.getChildren().addAll(k, v);
        return row;
    }

    public Pane getRoot() {
        return root;
    }
}
