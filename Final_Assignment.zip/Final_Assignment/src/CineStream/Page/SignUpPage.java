package CineStream.Page;

import CineStream.ImageStore;
import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.UserStore;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.regex.Pattern;

/**
 * Creates an in-memory CineStream account.
 *
 * The page validates Gmail format, both password fields and duplicate email
 * state before calling UserStore.register, then routes the user to LoginPage.
 */
public class SignUpPage {
    private final MainApp app;
    private final BorderPane root;
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@gmail\\.com$");

    public SignUpPage(MainApp app) {
        this.app = app;
        root = new BorderPane();
        root.setTop(new NavBar(app, ""));

        VBox card = new VBox(14);
        card.getStyleClass().addAll("card", "auth-card");
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(30, 42, 30, 42));
        card.setPrefWidth(430);
        card.setMaxWidth(430);

        Label kicker = new Label("◆ JOIN CINESTREAM");
        kicker.getStyleClass().add("muted-text");
        kicker.setStyle("-fx-text-fill: #b18cff; -fx-font-weight: bold;");

        Label title = new Label("Create Account");
        title.getStyleClass().add("title-label");

        Label sub = new Label("Sign up free and start booking");
        sub.getStyleClass().add("subtitle-label");

        // Email
        Label lblEmail = new Label("EMAIL ADDRESS");
        lblEmail.getStyleClass().add("field-label");
        TextField tfEmail = new TextField();
        tfEmail.setPromptText("yourname@gmail.com");

        // Password
        Label lblPass = new Label("PASSWORD");
        lblPass.getStyleClass().add("field-label");
        PasswordField pfPassword = new PasswordField();
        pfPassword.setPromptText("Create a password");
        HBox passBox = new HBox(10);
        HBox.setHgrow(pfPassword, Priority.ALWAYS);
        passBox.getChildren().add(pfPassword);

        // Confirm password
        Label lblConfirm = new Label("CONFIRM PASSWORD");
        lblConfirm.getStyleClass().add("field-label");
        PasswordField pfConfirm = new PasswordField();
        pfConfirm.setPromptText("Re-enter your password");

        // Validate and register the account, then route to LoginPage.
        Button btnRegister = new Button("Create Account");
        btnRegister.getStyleClass().add("button-full");
        btnRegister.setOnAction(e -> {
            String email = tfEmail.getText().trim();
            String pass = pfPassword.getText().trim();
            String confirm = pfConfirm.getText().trim();

            if (!EMAIL_PATTERN.matcher(email).matches()) {
                new Alert(Alert.AlertType.ERROR, "Please enter a valid Gmail address.").show();
                return;
            }
            if (pass.isEmpty() || confirm.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Password fields cannot be empty.").show();
                return;
            }
            if (!pass.equals(confirm)) {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").show();
                return;
            }
            if (UserStore.getInstance().isRegistered(email)) {
                new Alert(Alert.AlertType.ERROR, "This email is already registered. Please login.").show();
                return;
            }

            UserStore.getInstance().register(email, pass);
            new Alert(Alert.AlertType.INFORMATION, "Registration successful! You can now log in.").show();
            app.navigateTo(new LoginPage(app).getRoot());
        });

        // Existing users can return directly to LoginPage.
        Separator sep = new Separator();
        HBox loginRow = new HBox(6);
        loginRow.setAlignment(Pos.CENTER);
        Label hasAccount = new Label("Already have an account?");
        hasAccount.getStyleClass().add("muted-text");
        Hyperlink linkLogin = new Hyperlink("Login");
        linkLogin.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        linkLogin.setOnAction(e -> app.navigateTo(new LoginPage(app).getRoot()));
        loginRow.getChildren().addAll(hasAccount, linkLogin);

        // Return without changing authentication state.
        Button btnBack = new Button("←  Back to Home");
        btnBack.getStyleClass().addAll("button-secondary", "button-full");
        btnBack.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        card.getChildren().addAll(kicker, title, sub,
                lblEmail, tfEmail, lblPass, passBox, lblConfirm, pfConfirm,
                btnRegister, sep, loginRow, btnBack);

        // The form stays centred with breathing room below the menu bar.
        // The supplied popcorn photo is blurred and fades back into the
        // application's original background colour toward the bottom.
        VBox pageContent = new VBox(card);
        pageContent.setAlignment(Pos.CENTER);
        pageContent.setPadding(new Insets(38, 24, 44, 24));
        root.setCenter(Ui.blurredBackdrop(
                ImageStore.popcornBackground(),
                Responsive.wrapScrollFill(pageContent, -1)));
    }

    public Pane getRoot() {
        return root;
    }
}
