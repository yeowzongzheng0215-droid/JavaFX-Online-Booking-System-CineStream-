package CineStream.Page;

import CineStream.MainApp;
import CineStream.Responsive;
import CineStream.Ui;
import CineStream.Model.ReceiptGenerator;
import CineStream.Model.Ticket;
import CineStream.UserSession;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Random;

/**
 * Presents the final electronic ticket after payment succeeds.
 *
 * ReceiptGenerator snapshots UserSession into a Ticket when this page is built.
 * The card then combines that immutable ticket data with the selected movie's
 * real poster. Actions simulate printing, clear state for another booking, or
 * return home while preserving the completed Reservation in booking history.
 */
public class TicketPage {
    private final MainApp app;
    private final BorderPane root;
    private final Ticket ticket;

    public TicketPage(MainApp app) {
        this.app = app;
        // Generate once so every label and the barcode share one booking reference.
        this.ticket = ReceiptGenerator.generateTicket(UserSession.getInstance());
        root = new BorderPane();
        root.setTop(new NavBar(app, "ticket"));

        VBox center = new VBox(0);
        center.getChildren().addAll(
                new StepsBar(3),
                new MovieHeroBanner(UserSession.getInstance().getSelectedMovie()));

        /* ================= Electronic ticket card ================= */
        VBox ticketCard = new VBox(0);
        ticketCard.getStyleClass().add("ticket-card");
        ticketCard.setPrefWidth(540);
        ticketCard.setMaxWidth(540);

        // Ticket header contains brand and unique booking reference.
        HBox header = new HBox(10);
        header.getStyleClass().add("ticket-header");
        header.setAlignment(Pos.CENTER_LEFT);

        javafx.scene.image.ImageView logoImg = CineStream.Ui.logoView(32);

        VBox headTxt = new VBox(1);
        Label brand = new Label("CINESTREAM");
        brand.setStyle("-fx-text-fill: #ffffff; -fx-font-size: 15px; -fx-font-weight: bold;");
        Label ticketType = new Label("E-TICKET  •  CONFIRMED");
        ticketType.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 10.5px; -fx-font-weight: 600;");
        headTxt.getChildren().addAll(brand, ticketType);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        VBox idBox = new VBox(1);
        idBox.setAlignment(Pos.CENTER_RIGHT);
        Label idKey = new Label("BOOKING REF");
        idKey.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 9.5px; -fx-font-weight: 600;");
        Label idVal = new Label(ticket.getTicketId());
        idVal.getStyleClass().add("ticket-id");
        idBox.getChildren().addAll(idKey, idVal);

        header.getChildren().addAll(logoImg, headTxt, spacer, idBox);

        // Ticket body presents the selected movie and booking details.
        VBox body = new VBox(12);
        body.setPadding(new Insets(22, 30, 24, 30));

        // Movie title + the same corresponding real poster used on Home.
        HBox movieRow = new HBox(16);
        movieRow.setAlignment(Pos.CENTER_LEFT);
        StackPane miniPoster = Ui.moviePosterImage(
                UserSession.getInstance().getSelectedMovie(), 86, 120, 10);
        VBox movieTxt = new VBox(6);
        Label movieTitle = new Label(ticket.getMovieTitle());
        movieTitle.getStyleClass().add("ticket-movie-title");
        Label movieGenre = new Label(UserSession.getInstance().getSelectedMovie().getGenre()
                + "  •  " + UserSession.getInstance().getSelectedMovie().getDuration() + " min");
        movieGenre.getStyleClass().add("muted-text");
        movieTxt.getChildren().addAll(movieTitle, movieGenre);
        movieRow.getChildren().addAll(miniPoster, movieTxt);

        // Structured customer, hall, showtime, seat and payment rows.
        VBox details = new VBox(4);
        details.getChildren().add(detailRow("Customer", ticket.getUsername()));
        details.getChildren().add(detailRow("Cinema Hall", ticket.getHallName()));
        details.getChildren().add(detailRow("Show Date & Time", ticket.getShowtimeStr()));
        details.getChildren().add(detailRow("Seat(s)", ticket.getSeatNumbers()));
        details.getChildren().add(detailRow("Total Paid", String.format("RM %.2f", ticket.getTotalPrice())));

        // Deterministic decorative barcode based on the ticket ID.
        VBox barcodeBox = new VBox(4);
        barcodeBox.setAlignment(Pos.CENTER);
        barcodeBox.setPadding(new Insets(6, 0, 2, 0));

        HBox bars = new HBox(2);
        bars.setAlignment(Pos.CENTER);
        // A seeded Random makes the decorative barcode stable for this ticket ID.
        Random rnd = new Random(ticket.getTicketId().hashCode());
        for (int i = 0; i < 46; i++) {
            Rectangle bar = new Rectangle(rnd.nextInt(3) + 1, 42);
            bar.setFill(Color.web("#e9e2fa"));
            bars.getChildren().add(bar);
        }

        Label scanHint = new Label("SCAN THIS BARCODE AT THE CINEMA ENTRANCE");
        scanHint.getStyleClass().add("muted-text");
        scanHint.setStyle("-fx-font-size: 9.5px; -fx-font-weight: bold;");

        barcodeBox.getChildren().addAll(bars, scanHint);

        body.getChildren().addAll(movieRow, details, barcodeBox);

        ticketCard.getChildren().addAll(header, body);

        // Post-booking actions: print, start another order, or return home.
        HBox btnRow = new HBox(12);
        btnRow.setAlignment(Pos.CENTER);
        btnRow.setPadding(new Insets(18, 0, 6, 0));

        Button btnPrint = new Button("Print Ticket");
        btnPrint.getStyleClass().addAll("button-secondary", "button-small");
        btnPrint.setOnAction(e -> new Alert(Alert.AlertType.INFORMATION,
                "Ticket printed successfully.\nTicket ID: " + ticket.getTicketId()).show());

        // Clear only booking choices; the member remains logged in for the next order.
        Button btnAnother = new Button("Book Another Movie");
        btnAnother.getStyleClass().addAll("button-secondary", "button-small");
        btnAnother.setOnAction(e -> {
            UserSession.getInstance().clearBookingSelection();
            app.navigateTo(new MoviePage(app).getRoot());
        });

        Button btnHome = new Button("Back to Home");
        btnHome.getStyleClass().addAll("button-small");
        btnHome.setOnAction(e -> app.navigateTo(new HomePage(app).getRoot()));

        btnRow.getChildren().addAll(btnPrint, btnAnother, btnHome);

        VBox wrap = new VBox(0, ticketCard, btnRow);
        wrap.setAlignment(Pos.CENTER);
        // Leave enough room below all three actions at every window size.
        wrap.setPadding(new Insets(24, 24, 96, 24));

        center.getChildren().add(wrap);
        root.setCenter(Responsive.wrapScroll(center, -1));
    }

    /** Creates one aligned information row inside the ticket body. */
    private HBox detailRow(String key, String value) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("detail-row");
        Label k = new Label(key);
        k.getStyleClass().add("detail-key");
        k.setPrefWidth(128);
        Label v = new Label(value);
        v.getStyleClass().add("detail-value");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        row.getChildren().addAll(k, v);
        return row;
    }

    public Pane getRoot() {
        return root;
    }
}
