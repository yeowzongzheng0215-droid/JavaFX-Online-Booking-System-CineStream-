package CineStream.Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;

/**
 * Read-only e-ticket snapshot generated from a completed booking.
 *
 * Values are converted to display strings in the constructor so TicketPage and
 * the booking-history dialog can render the same stable information even if the
 * active UserSession later starts another order.
 */
public class Ticket {
    private final String ticketId;
    private final String username;
    private final String movieTitle;
    private final String hallName;
    private final String showtimeStr;
    private final String seatNumbers;
    private final String issueTime;
    private final double totalPrice;

    /** Captures booking data and calculates the final paid amount. */
    public Ticket(String ticketId, String username, MovieData movie, Showtime showtime,
                  java.util.List<Seat> seats, double pricePerSeat) {
        this.ticketId = ticketId;
        this.username = username;
        this.movieTitle = movie.getTitle();
        this.hallName = showtime.getHall().getName();
        this.showtimeStr = showtime.getTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm"));
        this.seatNumbers = seats.stream().map(Seat::getSeatNumber).collect(Collectors.joining(", "));
        this.issueTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm:ss"));
        this.totalPrice = seats.size() * pricePerSeat;
    }

    /** Plain-text representation used by the booking-history information dialog. */
    public String getTicketText() {
        return "============================================\n"
                + "            CINESTREAM E-TICKET\n"
                + "============================================\n"
                + "Ticket ID        : " + ticketId + "\n"
                + "Customer         : " + username + "\n"
                + "Movie Title      : " + movieTitle + "\n"
                + "Cinema Hall      : " + hallName + "\n"
                + "Show Date & Time : " + showtimeStr + "\n"
                + "Seat Number(s)   : " + seatNumbers + "\n"
                + "Issue Time       : " + issueTime + "\n"
                + "Total Amount     : RM " + String.format("%.2f", totalPrice) + "\n"
                + "============================================\n"
                + "Please arrive on time and enjoy your movie!\n"
                + "============================================\n";
    }

    public String getTicketId() { return ticketId; }
    public String getUsername() { return username; }
    public String getMovieTitle() { return movieTitle; }
    public String getHallName() { return hallName; }
    public String getShowtimeStr() { return showtimeStr; }
    public String getSeatNumbers() { return seatNumbers; }
    public String getIssueTime() { return issueTime; }
    public double getTotalPrice() { return totalPrice; }
}
