package CineStream.Model;

/**
 * Describes one movie shown by the catalogue.
 *
 * Page classes read this object to resolve poster/banner assets, display movie
 * metadata and filter the matching Showtime records.  MovieCatalogue owns the
 * shared instances, so page navigation passes references instead of copying data.
 */
public class MovieData {
    private String title;
    private String posterPath;
    private String description;
    private int duration;
    private int colorIndex;
    private String rating;

    /** Convenience constructor retained for older code that uses default styling. */
    public MovieData(String title, String posterPath, String description, int duration) {
        this(title, posterPath, description, duration, 0, "P13");
    }

    /** Creates a complete movie record including fallback colour and age rating. */
    public MovieData(String title, String posterPath, String description, int duration,
                     int colorIndex, String rating) {
        this.title = title;
        this.posterPath = posterPath;
        this.description = description;
        this.duration = duration;
        this.colorIndex = colorIndex;
        this.rating = rating;
    }

    public String getTitle() { return title; }
    public String getPosterPath() { return posterPath; }
    public String getDescription() { return description; }
    public int getDuration() { return duration; }
    public int getColorIndex() { return colorIndex; }
    public String getRating() { return rating; }

    /** The current data model stores the genre text in the description field. */
    public String getGenre() { return description; }

    /** Used by controls or diagnostics that render a MovieData as plain text. */
    @Override
    public String toString() {
        return title + " (" + duration + " minute)";
    }
}
