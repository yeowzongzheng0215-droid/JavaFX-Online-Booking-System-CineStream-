package CineStream.Model;

/**
 * One seat coordinate and its current UI/booking state.
 *
 * AVAILABLE can be selected, SELECTED is a temporary local choice, and BOOKED
 * is committed by BookingUtils and cannot be chosen again.
 */
public class Seat {
    public enum Status { AVAILABLE, SELECTED, BOOKED }

    /** Zero-based row and column coordinates inside a SeatMap. */
    private final int row;
    private final int col;
    private Status status;

    public Seat(int row, int col) {
        this.row = row;
        this.col = col;
        this.status = Status.AVAILABLE;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    /** Converts zero-based coordinates into the customer-facing form A1, B5, etc. */
    public String getSeatNumber() {
        return String.format("%c%d", 'A' + row, col + 1);
    }
}
