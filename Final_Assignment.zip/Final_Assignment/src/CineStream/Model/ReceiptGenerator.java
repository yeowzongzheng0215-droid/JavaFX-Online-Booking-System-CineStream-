package CineStream.Model;

import CineStream.UserSession;
import java.util.UUID;

/**
 * Converts the active UserSession booking into a Ticket/receipt snapshot.
 * Centralising the unit price keeps SeatPage, payment summaries and tickets
 * consistent.
 */
public class ReceiptGenerator {
    /** Fixed assignment price used by every fare calculation. */
    public static final double PRICE_PER_SEAT = 18.0;

    /**
     * Generates a unique booking reference and copies all active session data
     * into a new Ticket object.
     */
    public static Ticket generateTicket(UserSession session) {
        String ticketId = "CS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return new Ticket(
                ticketId,
                session.getUsername(),
                session.getSelectedMovie(),
                session.getSelectedShowtime(),
                session.getSelectedSeats(),
                PRICE_PER_SEAT
        );
    }

    /** Legacy text-receipt API backed by the same Ticket generation path. */
    public static String generateReceipt(UserSession session) {
        return generateTicket(session).getTicketText();
    }

    public static double getPricePerSeat() {
        return PRICE_PER_SEAT;
    }
}
