package CineStream.Model;

/**
 * Two-dimensional seat inventory owned by one Showtime.
 * SeatPage renders this array directly, while BookingUtils performs the
 * synchronized commit that changes selected seats to BOOKED.
 */
public class SeatMap {
    private final Seat[][] seats;

    /** Builds a rectangular grid whose seats all start as AVAILABLE. */
    public SeatMap(int rows, int cols) {
        seats = new Seat[rows][cols];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                seats[r][c] = new Seat(r, c);
            }
        }
    }

    public Seat[][] getSeats() { return seats; }
    public int getRowCount() { return seats.length; }
    public int getColumnCount() { return seats.length == 0 ? 0 : seats[0].length; }

    /**
     * A selected seat may be committed as booked; only an already booked seat
     * is rejected. This supports the UI transition SELECTED -> BOOKED.
     */
    public synchronized boolean bookSeat(int row, int col) {
        Seat seat = seats[row][col];
        if (seat.getStatus() == Seat.Status.BOOKED) {
            return false;
        }
        seat.setStatus(Seat.Status.BOOKED);
        return true;
    }

    /** Restores every coordinate; intended for development/reset scenarios. */
    public void resetAll() {
        for (Seat[] row : seats) {
            for (Seat seat : row) {
                seat.setStatus(Seat.Status.AVAILABLE);
            }
        }
    }
}
