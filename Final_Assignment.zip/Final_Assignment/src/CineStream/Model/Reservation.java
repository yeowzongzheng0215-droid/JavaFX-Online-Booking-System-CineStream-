package CineStream.Model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Immutable booking-history record created after successful payment.
 * BookingHistoryPage filters these records by username and can rebuild a text
 * Ticket from the stored movie, showtime and seat references.
 */
public class Reservation {
    private final String username;
    private final MovieData movie;
    private final Showtime showtime;
    private final List<Seat> seats;
    private final LocalDateTime bookTime;

    public Reservation(String username, MovieData movie, Showtime showtime, List<Seat> seats) {
        this.username = username;
        this.movie = movie;
        this.showtime = showtime;
        // A defensive, unmodifiable copy prevents later UserSession changes
        // from clearing seat details in an already completed history record.
        this.seats = Collections.unmodifiableList(new ArrayList<>(seats));
        this.bookTime = LocalDateTime.now();
    }

    public String getUsername() { return username; }
    public MovieData getMovie() { return movie; }
    public Showtime getShowtime() { return showtime; }
    public List<Seat> getSeats() { return seats; }
    public LocalDateTime getBookTime() { return bookTime; }
}
