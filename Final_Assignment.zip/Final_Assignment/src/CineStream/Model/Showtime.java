package CineStream.Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Connects a MovieData record, start time, physical hall and independent seat
 * inventory. MoviePage filters these objects by movie; every later booking page
 * reads the selected instance from UserSession.
 */
public class Showtime {
    private final MovieData movie;
    private final LocalDateTime time;
    private final ScreeningHall hall;
    private final SeatMap seatMap;

    public Showtime(MovieData movie, LocalDateTime time, ScreeningHall hall) {
        this.movie = movie;
        this.time = time;
        this.hall = hall;
        // Seat availability belongs to this performance, not every film using
        // the same physical hall. Only the hall dimensions are copied.
        this.seatMap = new SeatMap(
                hall.getSeatMap().getRowCount(),
                hall.getSeatMap().getColumnCount());
    }

    public MovieData getMovie() { return movie; }
    public LocalDateTime getTime() { return time; }
    public ScreeningHall getHall() { return hall; }
    public SeatMap getSeatMap() { return seatMap; }

    /** Compact representation useful in logs and standard JavaFX controls. */
    @Override
    public String toString() {
        return String.format("%s | %s | %s",
                movie.getTitle(),
                time.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                hall.getName());
    }
}
