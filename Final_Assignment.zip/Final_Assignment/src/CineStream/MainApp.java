package CineStream;

import CineStream.Page.HomePage;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/** Main JavaFX application and page navigator. */
public class MainApp extends Application {
    private static Stage primaryStage;
    private static Scene primaryScene;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("CineStream - Online Movie Booking System");

        primaryStage.setResizable(true);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(640);
        primaryStage.setMaximized(true);

        navigateTo(new HomePage(this).getRoot());
        primaryStage.show();
        scheduleLayoutRefresh(primaryScene.getRoot());
    }

    /**
     * Reuse one Scene and replace only its root.  Replacing the whole Scene on
     * every navigation caused JavaFX ScrollPane skins to miss their first
     * layout pulse: scroll bars disappeared and page bottoms were clipped until
     * the user resized the window.  A stable Scene removes that timing issue.
     */
    public void navigateTo(Pane root) {
        if (primaryScene == null) {
            primaryScene = new Scene(root, 1280, 800);
            primaryScene.getStylesheets().add(
                    getClass().getResource("style.css").toExternalForm());
            primaryStage.setScene(primaryScene);
        } else {
            primaryScene.setRoot(root);
            if (primaryStage.getScene() != primaryScene) {
                primaryStage.setScene(primaryScene);
            }
        }
        scheduleLayoutRefresh(root);
    }

    /**
     * Force two normal JavaFX pulses after a page enters the Scene.  The second
     * pulse runs after controls have created their skins, ensuring ScrollPane
     * viewport size, vertical bar and bottom padding are correct immediately.
     */
    private void scheduleLayoutRefresh(Node root) {
        Platform.runLater(() -> {
            refreshLayout(root);
            Platform.runLater(() -> refreshLayout(root));
        });
    }

    private void refreshLayout(Node root) {
        if (root == null || root.getScene() != primaryScene) return;
        root.applyCss();
        if (root instanceof Parent) {
            ((Parent) root).requestLayout();
        }
        if (root instanceof Pane) {
            ((Pane) root).layout();
        }
        for (Node node : root.lookupAll(".persistent-scroll")) {
            node.applyCss();
            if (node instanceof Parent) {
                ((Parent) node).requestLayout();
            }
            if (node instanceof ScrollPane) {
                ScrollPane scroll = (ScrollPane) node;
                scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
                if (scroll.getContent() instanceof Parent) {
                    ((Parent) scroll.getContent()).requestLayout();
                }
            }
        }
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public javafx.application.HostServices host() {
        return getHostServices();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
