# 🎬 CineStream — Online Movie Booking System（UI 重设计版）

> JavaFX Final Assignment 项目。在保留原有全部功能的基础上，将 UI 重设计为
> 接近真实在线电影订票系统的深紫色主题界面。

## 2026-08-09 需求追加修改（Version 3.1）

- **ScrollBar / 首次布局修复**：全站导航改为复用同一个 JavaFX `Scene`，并在新页面 Skin 建立后补两次正常布局脉冲；Home、Now Showing、Seat、Payment 与 Ticket 的纵向 ScrollBar 返回页面后仍会保持显示，不再需要手动缩放窗口才能刷新底部布局。
- **Now Showing Hover**：真实海报卡片加入与 Home 相同的 150ms、1.04 倍鼠标移入放大及移出还原效果。
- **Seat / Payment / Ticket 底部空间**：增加明确的下方留白，Ticket 的 Print Ticket / Book Another Movie / Back to Home 可正常滚动显示；所选电影 Banner 的暗层覆盖顺序与底边渐变已修正，并加入防止子像素亮线的底边保护。
- **Login / Sign Up / My Tickets**：使用用户提供的爆米花图片作为模糊背景，并从页面下半部渐变回原本深紫背景；登录与注册卡片和顶部菜单保留舒适间距。
- **About**：使用用户提供的红窗帘模糊背景，下半部渐变回原背景，原卡片内容保持不变。
- **Now Showing**：步骤连接线改细；步骤条下加入与 Home 相同的电影轮播；选片区改用 Home 的真实海报，海报在左、`YOUR SELECTION` 在右，`Select Showtime` 位于两者下方；星期固定使用完整英文（如 `Saturday`）。
- **Seats / Booking Summary / Confirmation / Payment / Ticket**：步骤条下方显示当前所选电影的对应 Banner，并向下渐变融入页面背景；Seat 页面左右卡片适度放大；Ticket 小海报使用 Home 对应真实海报。
- **My Tickets Footer**：短内容或空状态时 Footer 会被推到页面最底部；内容变长时仍可正常滚动。
- **登录保护**：Home Footer 的 `Now Showing`、`My Tickets` 与顶部菜单使用相同登录检查；未登录时显示提示并自动进入 Login。
- **重复订座修复**：座位状态改为每一个 Showtime 独立保存；`SELECTED → BOOKED` 正确提交，已订座始终显示 `BOOKED` 且不能再次预订；预置已售座位不会被“修改座位”功能误释放。
- **历史记录修复**：Reservation 对座位列表做防御性复制，登出或开始新订单后旧订单座位不会消失。

新增资源：

- `src/CineStream/images/background-popcorn.png`
- `src/CineStream/images/background-curtain.png`
- `src/CineStream/Page/MovieHeroBanner.java`

## 响应式窗口（本次新增）

- **窗口可自由缩放**（`setResizable(true)`），最小 900×640，**初始最大化铺满整个屏幕**
- 每个页面内容宽度跟随窗口：窄屏填满、超大屏（>上限值）自动居中，不拉伸变形
- 内容超高时自动出现垂直滚动条，任何屏幕大小都不会截断或溢出
- 页面切换（`navigateTo`）后新页面保持当前窗口尺寸
- 若想改为隐藏标题栏的真全屏，把 `MainApp.start()` 中
  `primaryStage.setMaximized(true)` 改成 `primaryStage.setFullScreen(true)` 即可

## 配色方案

| 用途 | 色值 |
|------|------|
| Primary（主色） | `#7630e7` |
| Button（按钮） | `#420e96`（hover 变亮 → `#5a1cc9`，按下 → `#7630e7`） |
| Background | 黑色混 `#7630e7` 的深紫渐变（`#05050d → #120826 → #1e0e3f`） |
| Text | 白色 `#ffffff`，辅助文字 `#cfc3ee / #8f7fc0` |

## 本次改动

### 新增文件
- `src/CineStream/Page/NavBar.java` — 全站顶部导航栏（Logo + Home / Now Showing / My Tickets / About + 用户区 + Logout），**每个页面都能跳转到其他页面**
- `src/CineStream/Page/StepsBar.java` — 订票流程步骤条（Movie → Seats → Payment → Ticket）
- `src/CineStream/Ui.java` — 共享 UI 工具（电影海报、渐变、首字母缩写）
- `src/CineStream/MovieCatalogue.java` — 共享电影/场次数据源（单例），并预置部分已售座位模拟真实影院

### 重设计页面（功能全部保留）
| 页面 | 新设计 |
|------|--------|
| HomePage | Hero 渐变横幅 + 正在上映电影卡片（点击卡片直达选片页）+ 功能亮点栏；登录/未登录两种状态 |
| LoginPage / SignUpPage | 居中玻璃卡片、字段标签、登录↔注册互相跳转链接 |
| MoviePage | 6 部电影 3×2 卡片网格（点击选中高亮）+ 场次 chips（自动选中第一场）+ 右侧实时选择摘要 |
| SeatPage | 弧形屏幕标识 + A–H 行座位图 + 图例 + 右侧实时摘要（座位标签、数量、总价）；从确认页「修改座位」返回时自动恢复已选座位 |
| PricePage | 订单摘要收据样式（明细 + 总价大字） |
| ConfirmPage | 预订详情确认 + 修改座位（会先释放已锁定座位） |
| PaymentPage | 三种支付方式（Card / E-Wallet / FPX）+ 卡片输入校验 + 右侧订单摘要 |
| TicketPage | 电子票卡片：紫色票头（BOOKING REF）+ 电影信息 + 明细 + 确定性条形码 + 操作按钮 |
| BookingHistoryPage | 预订记录卡片列表（每张卡片独立 View E-Ticket 按钮）+ 空状态引导 |
| AboutPage / CinemaPage / DatePage | 统一新主题重做 |

### 功能修复
- 原版每次进入 MoviePage 都会新建 3 个放映厅，第 4 次触发「系统最多支持 12 个放映厅」崩溃 → 改为单例数据源
- 原版「修改座位」后座位仍显示已锁定 → 新增 `BookingUtils.releaseSeats()`，确认页修改座位时先释放
- 窗口可缩放 + 初始最大化，布局全面响应式（见上）

## 如何运行

与原来完全相同（环境需 JDK 16+ 与 JavaFX SDK）：

```bash
# 方式一：IDE 中运行
运行 CineStream.MainApp

# 方式二：命令行（假设 JavaFX SDK 在 javafx-sdk/lib）
javac --module-path "javafx-sdk/lib" --add-modules javafx.controls,javafx.fxml -d bin src/CineStream/**/*.java src/CineStream/*.java
java  --module-path "javafx-sdk/lib" --add-modules javafx.controls,javafx.fxml -cp bin CineStream.MainApp
```

## 业务逻辑（未改动，均保留）
- Gmail 注册/登录（UserStore，仅运行时有效）
- 选电影 → 选场次 → 选座位 → 订单摘要 → 确认 → 支付 → 电子票
- 座位防重复预订（BookingUtils 全局锁定）
- RM 18.00 / 座 自动计价
- 预订历史（ALL_BOOKINGS）+ 电子票查看

## 首页（HomePage）新设计

布局（从上到下）：
1. **NavBar** 顶部菜单栏
2. **快捷卡片**：Book Now / My Tickets（未登录显示 Login / Sign Up），高度紧凑 ~86px
3. **Now Showing 轮播 Banner**（全宽版）：
   - 前景 = 电影 banner，**全屏宽度** × 500 高（cover 显示），明亮清晰
   - 自动轮播：停留 5s → **交叉淡化切换**（旧图 1.3s 慢消失 + 新图 1.3s 慢显现，同时进行）
   - 左右**透明圆形箭头**（区域最左/最右，hover 放大变色）手动切换，切换后自动重置计时器
   - 底部圆点指示器（banner 正下方，可点击跳转）
4. **Now Showing 海报网格**：6 部电影（含 The Forbidden Kingdom / Dune: Part Three / Romantic Seoul）
   - 卡片 = **poster 竖长方形**（固定 224 宽），海报 cover 填满 200×300、**四角圆润**（圆角 14）
   - 无黑色多余空隙；hover 放大 4%
5. **Footer**：品牌介绍 + 联系我们（地址/电话/邮箱/营业时间）+ 快速链接 + 社交（Facebook/Instagram/X/YouTube，点击用系统浏览器打开）+ 版权行

### 图片资源约定
- 目录：`src/CineStream/images/`
- 命名：海报 `poster-<电影slug>.png`，横幅 `banner-<电影slug>.png`
- slug：电影标题小写、空格转 `-`
- 未提供图片时自动用同色系渐变占位（海报显示首字母缩略图，banner 显示片名大标题），提供后自动替换

### 当前图片映射（用户提供，已按分析归类）
| 电影 | Poster | Banner |
|------|--------|--------|
| The Wandering Earth 3 | 流浪地球风格竖版海报 | 灰蓝太空场景横版 |
| Zootopia 2 | 白底卡通海报（ONLY IN THEATERS NOVEMBER 26） | 官方 Zootopia 2 横幅 |
| Avengers: Final Chapter | 漫威紫红调海报（含 MARVEL STUDIOS 标识） | MARVEL STUDIOS 超宽横幅 |
| The Forbidden Kingdom | 冒险标语海报（The path is unsafe...） | 官方横幅（THE FORBIDDEN KINGDOM 字样） |
| Dune: Part Three | 棕金沙漠色调海报 | Dune Messiah 横幅（MESSIAH 字样） |
| Romantic Seoul | 白色明亮调海报 | 首尔城市天际线横幅 |

> 说明：所有图片已转为 PNG（规避 JPEG 解码器环境差异，质量无损）。

### 技术说明
- 轮播时序在 `BannerSlider.java`：`HOLD_SEC=4.5 / FADE_SEC=1.0 / GAP_SEC=2.0`
- 封面裁剪（cover）统一用非托管 ImageView + 手动居中，保证任何屏幕比例不拉伸变形
- 首页内容不限宽（banner 需要全屏），其余区块内容限宽 1400px 居中
